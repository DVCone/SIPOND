-- phpMyAdmin SQL Dump
-- version 4.7.7
-- https://www.phpmyadmin.net/
--
-- Host: localhost:3306
-- Generation Time: May 23, 2018 at 10:22 AM
-- Server version: 10.1.31-MariaDB-cll-lve
-- PHP Version: 5.6.30

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `sipy1897_siponddemo`
--

-- --------------------------------------------------------

--
-- Table structure for table `aaa`
--

CREATE TABLE `aaa` (
  `nourut` int(11) NOT NULL,
  `alamat` varchar(100) NOT NULL,
  `nama` varchar(100) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `aaa`
--

INSERT INTO `aaa` (`nourut`, `alamat`, `nama`) VALUES
(1, 'piyungan', 'yadi'),
(2, 'grendeng', 'emak');

-- --------------------------------------------------------

--
-- Table structure for table `aaa2`
--

CREATE TABLE `aaa2` (
  `nourut` int(11) NOT NULL,
  `nama` varchar(100) NOT NULL,
  `alamat` varchar(100) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `aaa2`
--

INSERT INTO `aaa2` (`nourut`, `nama`, `alamat`) VALUES
(1, 'wida', 'kotabumi');

-- --------------------------------------------------------

--
-- Table structure for table `absen`
--

CREATE TABLE `absen` (
  `nourut` double NOT NULL,
  `nis` varchar(50) CHARACTER SET utf8 NOT NULL,
  `tanggal` date NOT NULL,
  `tanggalakhir` date NOT NULL,
  `sakit` int(11) NOT NULL,
  `ijin` int(11) NOT NULL,
  `alpa` int(11) NOT NULL,
  `catatan` varchar(100) CHARACTER SET utf8 NOT NULL,
  `pengguna` varchar(50) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `absentahfidz`
--

CREATE TABLE `absentahfidz` (
  `nis` varchar(100) NOT NULL,
  `tanggal` date NOT NULL,
  `sesi` int(11) NOT NULL,
  `sia` varchar(100) NOT NULL,
  `keterangan` varchar(200) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `acl_groups`
--

CREATE TABLE `acl_groups` (
  `id` int(11) NOT NULL,
  `nama` varchar(50) DEFAULT NULL,
  `status` varchar(50) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `acl_groups`
--

INSERT INTO `acl_groups` (`id`, `nama`, `status`) VALUES
(1, 'admin', 'MASTER'),
(6, 'cupa', NULL),
(7, 'Newbies', NULL),
(8, 'Alien', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `acl_menus`
--

CREATE TABLE `acl_menus` (
  `id` int(11) NOT NULL,
  `route` varchar(255) DEFAULT NULL,
  `group` varchar(50) DEFAULT '1',
  `sorting` int(11) DEFAULT NULL,
  `nama` varchar(50) DEFAULT NULL,
  `parent` enum('Y','N') DEFAULT 'N',
  `child` varchar(50) DEFAULT '0',
  `icon` varchar(50) DEFAULT NULL,
  `status` varchar(50) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `acl_menus`
--

INSERT INTO `acl_menus` (`id`, `route`, `group`, `sorting`, `nama`, `parent`, `child`, `icon`, `status`) VALUES
(1, NULL, '1', 4, 'Admin', 'Y', '46,51,7,8', 'widgets', NULL),
(2, 'index.php/welcome', '1,11,17,16,19', 1, 'Home', 'Y', '0', 'home', NULL),
(3, NULL, '1,11,16', 2, 'Tata Usaha', 'Y', '4,5,29', 'library_books', NULL),
(4, 'index.php/siswa/kartupelajar', '1,11', 1, 'Kartu Pelajar', 'N', '0', NULL, NULL),
(5, NULL, '1,11', 2, 'Siswa', 'N', '6,28', NULL, NULL),
(6, 'index.php/siswa/datalist_test', '1,11', 1, 'Data Siswa', 'N', '0', NULL, NULL),
(7, 'index.php/aclcontroller', '1,11', 1, 'Set Pengguna', 'N', '0', NULL, NULL),
(8, 'index.php/app/backup', '1,11', NULL, 'Backup & Restore', 'N', '0', NULL, NULL),
(9, NULL, '1', NULL, NULL, 'N', '0', NULL, NULL),
(10, NULL, '1', NULL, NULL, 'N', '0', NULL, NULL),
(11, NULL, '1,11,18,16,19', 3, 'Keuangan', 'Y', '25,26,27', 'monetization_on', NULL),
(12, NULL, '1,11', 5, 'Kesehatan', 'N', '52,53', 'local_pharmacy', NULL),
(13, NULL, '1,11', 6, 'Perizinan', 'N', '54,55', 'assignment', NULL),
(14, NULL, '1,11', 7, 'Pelanggaran', 'N', '56,57', 'warning', NULL),
(15, NULL, '1,11', 8, 'Prestasi', 'N', '58,59', 'verified_user', NULL),
(16, NULL, '1,11', 9, 'Tahfidz', 'N', '60,61', 'import_contacts', NULL),
(17, NULL, '1,11', 10, 'Nilai dan Raport', 'Y', '62,63,64,32,65', 'view_quilt', NULL),
(25, NULL, '1,11,18', NULL, 'Rutin', '', '33,34,35', NULL, NULL),
(26, NULL, '1,11,18', NULL, 'Jurnal', '', '36,37', NULL, NULL),
(27, NULL, '1,11,18', NULL, 'Laporan', '', '38,39,40,41,42,43,44,45', NULL, NULL),
(28, 'index.php/siswa/test', '1,11', NULL, 'Tambah Siswa', '', '0', NULL, NULL),
(29, NULL, '1,11', NULL, 'Guru / Karyawan', '', '30,31', NULL, NULL),
(30, 'index.php/karyawan/datalist', '1,11', NULL, 'Data Guru / Karyawan', '', '0', NULL, NULL),
(31, 'index.php/karyawan/test', '1,11', NULL, 'Tambah Guru / Karyawan', '', '0', NULL, NULL),
(32, 'index.php/keuanganrutin/kartupelajar', '1,11', NULL, 'Demo Raport', '', '0', NULL, NULL),
(33, 'index.php/keuanganrutin/', '1,11', NULL, 'Pemasukan Rutin', '', '0', NULL, NULL),
(34, 'index.php/keuangansettingsiswa/', '1,11', NULL, 'Setting Keuangan Siswa', '', '0', NULL, NULL),
(35, 'index.php/keuanganuangsakukeluar/', '1,11', NULL, 'Pengambilan Uang Saku', '', '0', NULL, NULL),
(36, 'index.php/jurnal/keluar/', '1,11', NULL, 'Jurnal Uang Keluar', '', '0', NULL, NULL),
(37, 'index.php/jurnal/masuk/', '1,11', NULL, 'Jurnal Uang Masuk', '', '0', NULL, NULL),
(38, 'index.php/keuanganrutin/datalist_spp', '1,11,18', NULL, 'Laporan SPP', 'N', '0', NULL, NULL),
(39, 'index.php/keuanganrutin/datalist_nospp', '1,11,18', NULL, 'Laporan Selain SPP', 'N', '0', NULL, NULL),
(40, 'index.php/keuanganrutin/cash', '1,11,18', NULL, 'Laporan Penerimaan Cash', '', '0', NULL, NULL),
(41, 'index.php/keuanganrutin/transfer', '1,11,18', NULL, 'Laporan Penerimaan Transfer', '', '0', NULL, NULL),
(42, 'index.php/keuanganuangsakukeluar/datalist', '1,11,18', NULL, 'Laporan Uang Saku Keluar', '', '0', NULL, NULL),
(43, 'index.php/keuanganrutin/datalistuangsakusisa', '1,11,18', NULL, 'Laporan Uang Saku Sisa', '', '0', NULL, NULL),
(44, 'index.php/keuanganrutin/datalistmonitoringspp', '1,11,18', NULL, 'Monitoring SPP', '', '0', NULL, NULL),
(45, '', '1,11', NULL, 'Akunting', '', '73,74,75', NULL, NULL),
(46, '', '1,11', NULL, 'Set Sekolah', '', '47,48,49', NULL, NULL),
(47, 'index.php/adminsetsekolah/', '1,11', NULL, 'Informasi Sekolah', '', '0', NULL, NULL),
(48, 'index.php/surat/sksekolah', '1,11', NULL, 'Surat Keterangan Bersekolah', '', '0', NULL, NULL),
(49, 'index.php/surat/spindah', '1,11', NULL, 'Surat Pindah Sekolah', '', '0', NULL, NULL),
(51, 'index.php/berita/', '1,11', NULL, 'Broadcast Berita', '', '0', NULL, NULL),
(52, 'index.php/kesehatan/test', '1,11', NULL, 'Isi Data Kesehatan', '', '0', NULL, NULL),
(53, 'index.php/kesehatan/datalist_kesehatan', '1,11', NULL, 'Laporan Kesehatan', '', '0', NULL, NULL),
(54, 'index.php/perizinan/test', '1,11', NULL, 'Isi Data Perizinan', '', '0', NULL, NULL),
(55, 'index.php/perizinan/datalist_perizinan', '1,11', NULL, 'Laporan Perizinan', '', '0', NULL, NULL),
(56, 'index.php/pelanggaran/test', '1,11', NULL, 'Isi Data Pelanggaran', '', '0', NULL, NULL),
(57, 'index.php/pelanggaran/datalist_pelanggaran', '1,11', NULL, 'Laporan Pelanggaran', '', '0', NULL, NULL),
(58, 'index.php/prestasi/test', '1,11', NULL, 'Isi Data Prestasi', '', '0', NULL, NULL),
(59, 'index.php/prestasi/datalist_prestasi', '1,11', NULL, 'Laporan Prestasi', '', '0', NULL, NULL),
(60, 'index.php/tahfidz/test', '1,11', NULL, 'Isi Data Tahfizh', '', '0', NULL, NULL),
(61, 'index.php/tahfidz/datalist', '1,11', NULL, 'Laporan Tahfizh', '', '0', NULL, NULL),
(62, '', '1,11', NULL, 'Mata Pelajaran', '', '66,67', NULL, NULL),
(63, 'index.php/nilai2/datalistsetting', '1,11', NULL, 'Setting Mapel & Guru', '', '68,69', NULL, NULL),
(64, NULL, '1,11', NULL, 'Laporan', '', '70,71,72', NULL, NULL),
(65, 'index.php/nilai/test', '1,11', NULL, 'Upload Data', '', '0', NULL, NULL),
(66, 'index.php/mapel/', '1,11', NULL, 'Tambah Mata Pelajaran', '', '0', NULL, NULL),
(67, 'index.php/mapel/datalist', '1,11', NULL, 'Data Mata Pelajaran', '', '0', NULL, NULL),
(68, 'index.php/nilai/settingmapel', '1,11', NULL, 'Setting', '', '0', NULL, NULL),
(69, 'index.php/nilai2/datalistsetting', '1,11', NULL, 'Daftar Setting Mapel', '', '0', NULL, NULL),
(70, 'index.php/nilai/laporannilai', '1,11', NULL, 'Laporan Nilai', '', '0', NULL, NULL),
(71, 'index.php/nilai/laporanperpengajar', '1,11', NULL, 'Laporan Per Pengajar', '', '0', NULL, NULL),
(72, 'index.php/nilai/laporanledgernilai', '1,11', NULL, 'Ledger Nilai', '', '0', NULL, NULL),
(73, 'index.php/keuanganlaporan/jurnal', '1,11', NULL, 'Laporan Jurnal', 'N', '0', NULL, NULL),
(74, 'index.php/keuanganlaporan/bukubesar', '1,11', NULL, 'Laporan Buku Besar', 'N', '0', NULL, NULL),
(75, 'index.php/keuanganlaporan/neracasaldo', '1,11', NULL, 'Laporan Neraca Saldo', 'N', '0', NULL, NULL),
(104, 'index.php/kesehatan', '1,17,16', 5, 'Kesehatan', 'Y', '0', 'local_pharmacy', NULL),
(105, 'index.php/perizinan', '1,11,17', 6, 'Perizinan', 'Y', '0', 'assignment', NULL),
(106, 'index.php/pelanggaran', '1,17', 7, 'Pelanggaran', 'Y', '0', 'warning', NULL),
(107, 'index.php/prestasi', '1,17,16', 8, 'Prestasi', 'Y', '0', 'verified_user', NULL),
(108, 'index.php/tahfidz', '1,16', 9, 'Tahfidz', 'Y', '0', 'import_contacts', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `acl_routes`
--

CREATE TABLE `acl_routes` (
  `id` int(11) NOT NULL,
  `group` varchar(50) NOT NULL DEFAULT '0',
  `key` varchar(50) NOT NULL,
  `controller` varchar(50) NOT NULL DEFAULT '0',
  `url` varchar(50) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `acl_routes`
--

INSERT INTO `acl_routes` (`id`, `group`, `key`, `controller`, `url`) VALUES
(1, '0', 'login', 'app/auth', 'f430193c40b21b08dcdaf403529135c1e20f830d'),
(2, '0', 'logout', 'app/logout', 'afb29d937c3328f537269e8d707ba2968fd51abb'),
(3, '0', 'backup', 'dbackup', 'e693b3e6e7574aeddb69937bed53be2cbfcbf68a'),
(4, '0', 'acl', 'app/acl_system', 'dbe20d0f379d2ce046b011f82df0afddaa584a72'),
(5, '0', 'acl_management', 'Aclcontroller', '9c564b6e4adaad9ab586806e1dbde45276047408'),
(6, '0', 'api_import', 'api', '732f3795730aec07a24660eb0cf10485cd89e983'),
(7, '0', 'api_get_user', 'api/users', '0c9dbd2186cb902db4f19ebb2911408cf4a2778e'),
(8, '0', 'api_add_user', 'api/add_user', '27332e4db84dd2b014d7717bbe156622efbbb046'),
(9, '0', 'api_get_group', 'api/groups', '29dfe4e0ac143e074dbd743df6359232cccdf555'),
(10, '0', 'api_add_group', 'api/add_group', '4c16e4cbf8447551aebaf0182ff974f8adf88e1c'),
(11, '0', 'api_delete_user', 'api/delete_user', 'f69a2f42e54d54226f47c3c38508e0b72b5a634b'),
(12, '0', 'api_update_user', 'api/update_user', 'fb6ec3ca6751d2f6978c4a053961774d3c20a49f'),
(13, '0', 'api_delete_group', 'api/delete_group', '4bb67702def14dd842c59e0bc494237c8b03f480'),
(14, '0', 'api_update_group', 'api/update_group', '26d50d58e49e90422e9df2bbf8bc40f39283937a'),
(15, '0', 'api_get_parent_menu', 'api/parent_menus', 'fa13fc8373f4f839718691b7aa3c88d226f8cbaa'),
(16, '0', 'api_sidebar', 'api/sidebar', '3d35b554a11c64ca72ec903c280cfb72174f611c'),
(17, '0', 'api_menu_update', 'api/menu_update', 'af356140632f8942cd5cf15dab2076d941d15343'),
(18, '0', 'home', 'home', '7ed59b4cd9c216b883da6fe8529cc801b44458cb'),
(21, '0', 'menu_backup', 'app/backup', 'eed2f257f7c4c275822070482426ada18e17b5c8'),
(20, '0', 'api_get_route', 'api/routes', '7548bcacd898e19db85e66d5b35febf597ea1b99'),
(22, '0', 'dobackup', 'app/dobackup', '5def59a441ddd34dbb552ab97486c74d7369f3d1'),
(23, '0', 'dorestore', 'app/restore', '81d8136e7aa1c26836e2372a72dab92722b2402c'),
(24, '0', 'api_add_route', 'api/add_route', '7d1639d6c6ee78ee57aedaa657a4852e3c016e2a'),
(25, '0', 'api_delete_route', 'api/delete_route', '7810c6a9652c8e10f980e365c85d54381c1aebc9'),
(27, '0', 'api_update_route', 'api/update_route', 'e59a363e1149d0b82bec9ba981ff000f742a086c'),
(28, '0', 'api_add_menu', 'api/add_menu', '4cf642f13ad7fec37a627508c50bbd579e73f2b9'),
(29, '0', 'api_add_submenu', 'api/insert_submenu', 'e59e1bfd695a630ab9cf68d8e3dbc64dcfa0a654'),
(30, '0', 'kartupelajar', 'siswa/kartupelajar', '44d3886bcf39d509e16884d67368d41bc699e62c'),
(31, '0', 'jurnal_keluar', 'jurnal/keluar', 'db6acd2042ffbda87e053579b05d00110236ab4b'),
(33, '0', 'simpan_jurnal_masuk', 'jurnal/simpan_masuk', 'c58ea71b6b989a751d66b4eb379fbc9980a9890e'),
(32, '0', 'simpan_jurnal_keluar', 'jurnal/simpan_keluar', '46ce169476be424fb57ef049f5d5a49707360f11'),
(34, '0', 'jurnal_masuk', 'jurnal/masuk', 'c99db81c039084067e70afb7625be938a538367a');

-- --------------------------------------------------------

--
-- Table structure for table `acl_users`
--

CREATE TABLE `acl_users` (
  `id` int(11) NOT NULL,
  `idgroup` varchar(20) NOT NULL,
  `username` varchar(20) NOT NULL,
  `password` varchar(50) NOT NULL,
  `kodenota` varchar(2) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `acl_users`
--

INSERT INTO `acl_users` (`id`, `idgroup`, `username`, `password`, `kodenota`) VALUES
(1, '1', 'admin', 'admin', 'AM'),
(16, '', 'cipa2', 'cipa2', 'cp'),
(15, '', 'rindaman', '', '12'),
(12, '8', 'reina', 'admin', 'KJ'),
(11, '6', 'cipa', 'admin', 'KL'),
(17, '', 'haris', '123', ''),
(18, '', 'heri', 'heri', 'uh'),
(19, '', 'dadang', 'dadang', 'ud');

-- --------------------------------------------------------

--
-- Table structure for table `ambilformulir`
--

CREATE TABLE `ambilformulir` (
  `nopendaftaran` double NOT NULL,
  `tanggaldaftar` date NOT NULL,
  `biaya` double NOT NULL,
  `nama` varchar(250) NOT NULL,
  `password` varchar(250) NOT NULL,
  `keterangan` varchar(200) NOT NULL,
  `notelpon` varchar(50) NOT NULL,
  `lulus` varchar(50) NOT NULL DEFAULT 'no',
  `anacc` varchar(200) NOT NULL,
  `transfer` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `ambilformulir`
--

INSERT INTO `ambilformulir` (`nopendaftaran`, `tanggaldaftar`, `biaya`, `nama`, `password`, `keterangan`, `notelpon`, `lulus`, `anacc`, `transfer`) VALUES
(1, '2017-03-01', 300000, 'ahmad', '28536', 'sw', '08495758', 'no', '', 'TRANSFER'),
(2, '2017-09-08', 300000, 'Robbi Ari Richardo', '45125', 'Non Yatim', '085798413140', 'no', '', 'TRANSFER'),
(3, '2017-09-12', 300000, 'Gaus', '446', 'Non Yatim', '085798413140', 'no', '', 'TRANSFER'),
(4, '2017-09-14', 300000, 'giri', '16401', 'Non Yatim', '085798413141', 'no', '', 'TRANSFER');

-- --------------------------------------------------------

--
-- Table structure for table `ambilformulirasli`
--

CREATE TABLE `ambilformulirasli` (
  `nopendaftaran` double NOT NULL DEFAULT '0',
  `tanggaldaftar` date NOT NULL,
  `biaya` double NOT NULL,
  `nama` varchar(250) NOT NULL,
  `password` varchar(250) NOT NULL,
  `keterangan` varchar(200) NOT NULL,
  `notelpon` varchar(50) NOT NULL,
  `lulus` varchar(50) NOT NULL DEFAULT 'no',
  `anacc` varchar(200) NOT NULL,
  `transfer` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `ambilformulirasli`
--

INSERT INTO `ambilformulirasli` (`nopendaftaran`, `tanggaldaftar`, `biaya`, `nama`, `password`, `keterangan`, `notelpon`, `lulus`, `anacc`, `transfer`) VALUES
(1, '2017-03-01', 300000, 'ahmad', '28536', 'sw', '08495758', 'no', '', 'TRANSFER'),
(2, '2017-09-08', 300000, 'Robbi Ari Richardo', '45125', 'Non Yatim', '085798413140', 'no', '', 'TRANSFER'),
(3, '2017-09-12', 300000, 'Gaus', '446', 'Non Yatim', '085798413140', 'no', '', 'TRANSFER'),
(4, '2017-09-14', 300000, 'giri', '16401', 'Non Yatim', '085798413141', 'no', '', 'TRANSFER');

-- --------------------------------------------------------

--
-- Table structure for table `autocomplete`
--

CREATE TABLE `autocomplete` (
  `nim` bigint(20) NOT NULL,
  `nama` varchar(30) NOT NULL,
  `jurusan` varchar(30) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `autocomplete`
--

INSERT INTO `autocomplete` (`nim`, `nama`, `jurusan`) VALUES
(1199870012, 'Muhammad Yusuf Hamdani', 'Teknik Informatika'),
(7779127910, 'Tutorial Web Design', 'Tutorial Website'),
(9998711120, 'Rahmayanti', 'PGSD');

-- --------------------------------------------------------

--
-- Table structure for table `bayarrutin`
--

CREATE TABLE `bayarrutin` (
  `nonota` varchar(15) NOT NULL,
  `nis` varchar(12) DEFAULT NULL,
  `tanggal` date DEFAULT NULL,
  `uangpangkal` double NOT NULL DEFAULT '0',
  `daftarulang` double NOT NULL DEFAULT '0',
  `infaq` double NOT NULL DEFAULT '0',
  `uangsakumasuk` double NOT NULL DEFAULT '0',
  `bimbel` double NOT NULL DEFAULT '0',
  `pengguna` varchar(20) DEFAULT NULL,
  `transfer` varchar(50) DEFAULT NULL,
  `keteranganinfaq` varchar(150) DEFAULT NULL,
  `juli` double NOT NULL DEFAULT '0',
  `agustus` double NOT NULL DEFAULT '0',
  `september` double NOT NULL DEFAULT '0',
  `oktober` double NOT NULL DEFAULT '0',
  `november` double NOT NULL DEFAULT '0',
  `desember` double NOT NULL DEFAULT '0',
  `januari` double NOT NULL DEFAULT '0',
  `februari` double NOT NULL DEFAULT '0',
  `maret` double NOT NULL DEFAULT '0',
  `april` double NOT NULL DEFAULT '0',
  `mei` double NOT NULL DEFAULT '0',
  `juni` double NOT NULL DEFAULT '0',
  `tanggaldokumen` date NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Dumping data for table `bayarrutin`
--

INSERT INTO `bayarrutin` (`nonota`, `nis`, `tanggal`, `uangpangkal`, `daftarulang`, `infaq`, `uangsakumasuk`, `bimbel`, `pengguna`, `transfer`, `keteranganinfaq`, `juli`, `agustus`, `september`, `oktober`, `november`, `desember`, `januari`, `februari`, `maret`, `april`, `mei`, `juni`, `tanggaldokumen`) VALUES
('3', '11700094', '2018-05-20', 0, 0, 0, 200000, 0, 'aaaaa', 'TRANSFER', '', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, '0000-00-00'),
('1', '11700108', '2018-05-19', 0, 0, 0, 0, 0, 'aaaaa', 'CASH', '', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, '0000-00-00'),
('2', '11700108', '2018-05-20', 0, 0, 0, 100000, 0, 'aaaaa', 'CASH', '', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, '0000-00-00'),
('4', '11700094', '2018-05-21', 0, 0, 0, 0, 0, 'aaaaa', 'CASH', '', 0, 0, 0, 0, 0, 0, 1000000, 1000000, 0, 0, 0, 0, '0000-00-00'),
('5', '11700093', '2018-05-21', 500000, 0, 0, 0, 0, 'aaaaa', 'CASH', '', 0, 0, 0, 0, 0, 0, 1000000, 1000000, 0, 0, 0, 0, '0000-00-00'),
('6', '11700070', '2018-05-21', 500000, 0, 0, 0, 0, 'aaaaa', 'CASH', '', 0, 0, 0, 0, 0, 0, 1000000, 1000000, 0, 0, 0, 0, '0000-00-00'),
('7', '11700094', '2018-05-21', 200000, 0, 0, 0, 0, 'aaaaa', 'CASH', '', 0, 0, 0, 0, 0, 0, 1000000, 1000000, 0, 0, 0, 0, '0000-00-00'),
('8', '11700094', '2018-05-21', 100000, 0, 0, 0, 0, 'aaaaa', 'CASH', '', 0, 0, 0, 0, 0, 0, 1000000, 1000000, 0, 0, 0, 0, '0000-00-00');

--
-- Triggers `bayarrutin`
--
DELIMITER $$
CREATE TRIGGER `updatemonitoring` AFTER INSERT ON `bayarrutin` FOR EACH ROW BEGIN

    IF (NEW.juli > 0)
    THEN
      UPDATE monitoringspp
      SET juli = NEW.juli
      WHERE nis = NEW.nis;
      INSERT INTO jurnal (tanggal,nonota,koderekening,kredit,keterangan,pengguna) 
      VALUES (NEW.tanggal,NEW.nonota,'600000',NEW.juli,'SPP Bulan Juli',NEW.pengguna);
    END IF;
    IF (NEW.agustus > 0)
    THEN
      UPDATE monitoringspp
      SET agustus = NEW.agustus
      WHERE nis = NEW.nis;
      INSERT INTO jurnal (tanggal,nonota,koderekening,kredit,keterangan,pengguna) 
      VALUES (NEW.tanggal,NEW.nonota,'600000',NEW.agustus,'SPP Bulan agustus',NEW.pengguna);
    END IF;
    IF (NEW.september > 0)
    THEN
      UPDATE monitoringspp
      SET september = NEW.september
      WHERE nis = NEW.nis;
      INSERT INTO jurnal (tanggal,nonota,koderekening,kredit,keterangan,pengguna) 
      VALUES (NEW.tanggal,NEW.nonota,'600000',NEW.september,'SPP Bulan september',NEW.pengguna);
    END IF;

    IF (NEW.oktober > 0)
    THEN
      UPDATE monitoringspp
      SET oktober = NEW.oktober
      WHERE nis = NEW.nis;
      INSERT INTO jurnal (tanggal,nonota,koderekening,kredit,keterangan,pengguna) 
      VALUES (NEW.tanggal,NEW.nonota,'600000',NEW.oktober,'SPP Bulan oktober',NEW.pengguna);
    END IF;
    IF (NEW.november > 0)
    THEN
      UPDATE monitoringspp
      SET november = NEW.november
      WHERE nis = NEW.nis;
      INSERT INTO jurnal (tanggal,nonota,koderekening,kredit,keterangan,pengguna) 
      VALUES (NEW.tanggal,NEW.nonota,'600000',NEW.november,'SPP Bulan november',NEW.pengguna);
    END IF;
    IF (NEW.desember > 0)
    THEN
      UPDATE monitoringspp
      SET desember = NEW.desember
      WHERE nis = NEW.nis;
      INSERT INTO jurnal (tanggal,nonota,koderekening,kredit,keterangan,pengguna) 
      VALUES (NEW.tanggal,NEW.nonota,'600000',NEW.desember,'SPP Bulan desember',NEW.pengguna);
    END IF;

    IF (NEW.januari > 0)
    THEN
      UPDATE monitoringspp
      SET januari = NEW.januari
      WHERE nis = NEW.nis;
      INSERT INTO jurnal (tanggal,nonota,koderekening,kredit,keterangan,pengguna) 
      VALUES (NEW.tanggal,NEW.nonota,'600000',NEW.januari,'SPP Bulan januari',NEW.pengguna);
    END IF;
    IF (NEW.februari > 0)
    THEN
      UPDATE monitoringspp
      SET februari = NEW.februari
      WHERE nis = NEW.nis;
      INSERT INTO jurnal (tanggal,nonota,koderekening,kredit,keterangan,pengguna) 
      VALUES (NEW.tanggal,NEW.nonota,'600000',NEW.februari,'SPP Bulan februari',NEW.pengguna);
    END IF;
    IF (NEW.maret > 0)
    THEN
      UPDATE monitoringspp
      SET maret = NEW.maret
      WHERE nis = NEW.nis;
      INSERT INTO jurnal (tanggal,nonota,koderekening,kredit,keterangan,pengguna) 
      VALUES (NEW.tanggal,NEW.nonota,'600000',NEW.maret,'SPP Bulan maret',NEW.pengguna);
    END IF;

    IF (NEW.april > 0)
    THEN
      UPDATE monitoringspp
      SET april = NEW.april
      WHERE nis = NEW.nis;
      INSERT INTO jurnal (tanggal,nonota,koderekening,kredit,keterangan,pengguna) 
      VALUES (NEW.tanggal,NEW.nonota,'600000',NEW.april,'SPP Bulan april',NEW.pengguna);
    END IF;
    IF (NEW.mei > 0)
    THEN
      UPDATE monitoringspp
      SET mei = NEW.mei
      WHERE nis = NEW.nis;
      INSERT INTO jurnal (tanggal,nonota,koderekening,kredit,keterangan,pengguna) 
      VALUES (NEW.tanggal,NEW.nonota,'600000',NEW.mei,'SPP Bulan mei',NEW.pengguna);
    END IF;
    IF (NEW.juni > 0)
    THEN
      UPDATE monitoringspp
      SET juni = NEW.juni
      WHERE nis = NEW.nis;
      INSERT INTO jurnal (tanggal,nonota,koderekening,kredit,keterangan,pengguna) 
      VALUES (NEW.tanggal,NEW.nonota,'600000',NEW.juni,'SPP Bulan juni',NEW.pengguna);
    END IF;

    IF (NEW.uangpangkal > 0)
    THEN
      INSERT INTO jurnal (tanggal,nonota,koderekening,kredit,keterangan,pengguna) 
      VALUES (NEW.tanggal,NEW.nonota,'600001',NEW.uangpangkal,NEW.nis,NEW.pengguna);
    END IF;

    IF (NEW.daftarulang > 0)
    THEN
      INSERT INTO jurnal (tanggal,nonota,koderekening,kredit,keterangan,pengguna) 
      VALUES (NEW.tanggal,NEW.nonota,'600002',NEW.daftarulang,NEW.nis,NEW.pengguna);
    END IF;

    IF (NEW.infaq > 0)
    THEN
      INSERT INTO jurnal (tanggal,nonota,koderekening,kredit,keterangan,pengguna) 
      VALUES (NEW.tanggal,NEW.nonota,'600005',NEW.infaq,NEW.nis,NEW.pengguna);
    END IF;

    IF (NEW.uangsakumasuk > 0)
    THEN
      INSERT INTO jurnal (tanggal,nonota,koderekening,kredit,keterangan,pengguna) 
      VALUES (NEW.tanggal,NEW.nonota,'400002',NEW.uangsakumasuk,NEW.nis,NEW.pengguna);
    END IF;

    IF (NEW.bimbel > 0)
    THEN
      INSERT INTO jurnal (tanggal,nonota,koderekening,kredit,keterangan,pengguna) 
      VALUES (NEW.tanggal,NEW.nonota,'400008',NEW.bimbel,NEW.nis,NEW.pengguna);
    END IF;
    IF (NEW.transfer = 'TRANSFER')
    THEN
      INSERT INTO jurnal (tanggal,nonota,koderekening,debet,keterangan,pengguna) 
      VALUES (NEW.tanggal,NEW.nonota,'200001',NEW.bimbel+NEW.uangsakumasuk+NEW.infaq+NEW.daftarulang+NEW.uangpangkal+NEW.januari+NEW.februari+NEW.maret+NEW.april+NEW.mei+NEW.juni+NEW.juli+NEW.agustus+NEW.september+NEW.oktober+NEW.november+NEW.desember,NEW.nis,NEW.pengguna);
    END IF;
    IF (NEW.transfer = 'CASH')
    THEN
      INSERT INTO jurnal (tanggal,nonota,koderekening,debet,keterangan,pengguna) 
      VALUES (NEW.tanggal,NEW.nonota,'100099',NEW.bimbel+NEW.uangsakumasuk+NEW.infaq+NEW.daftarulang+NEW.uangpangkal+NEW.januari+NEW.februari+NEW.maret+NEW.april+NEW.mei+NEW.juni+NEW.juli+NEW.agustus+NEW.september+NEW.oktober+NEW.november+NEW.desember,NEW.nis,NEW.pengguna);
    END IF;
END
$$
DELIMITER ;

-- --------------------------------------------------------

--
-- Table structure for table `berita`
--

CREATE TABLE `berita` (
  `noberita` int(11) NOT NULL,
  `ditujukan` varchar(233) NOT NULL,
  `tanggal` date NOT NULL,
  `judul` varchar(233) NOT NULL,
  `isi` text NOT NULL,
  `pj` varchar(233) NOT NULL,
  `tutup` varchar(1) NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `berita`
--

INSERT INTO `berita` (`noberita`, `ditujukan`, `tanggal`, `judul`, `isi`, `pj`, `tutup`) VALUES
(1, 'WALI SANTRI PUTRA-PUTRI', '2017-08-25', 'LIBUR IDUL ADHA', 'ICBB INFO: LIBUR IDUL ADHA AKAN DI MULAI TANGGAL 31 AGUSTUS - 5 SEPTEMBER', 'Mudir', '0'),
(2, 'WALI SANTRI PUTRI', '2017-08-24', 'LIBUR BULANAN', 'LIBUR BULANAN UNTUK BULAN SEPTEMBER DI TIADAKAN, DAN DIGANTI DENGAN LIBUR IDUL ADHA', 'Bag. Kesantrian', '0'),
(3, 'SELURUH WALI SANTRI', '2017-08-25', 'HIMBAUAN SPP BULANAN', 'Kepada Seluruh Wali santri, Hari ini sudah masuk tanggal 10 Agustus 2017, Bagi yang belum melunasi SPP Bulan Agustus 2017, Harap segera melunasi.rnBagi yang yang telah membayar, Harap abaikan berita ini, dan kami ucapkan Jazakumullohu Khoiron, ', 'Bag. Keuangan', '0'),
(4, 'Seluruh Walisantri', '2017-08-22', 'Unian Mid Semester', 'Kepada Seluruh Wali santri, Bahwa Mid Semester Akan dilaksanakan Bulan Oktober.rnSyarat Mengikuti Semester adalah Lunas SPP sampai Bulan Oktober.rnMohon Doa restunya agar Anak-Anak kita dapat lancar mengikuti Ujian, dan kami ucapkan Jazakumullohu Khoiron, ', 'Bag. KBM', '0'),
(6, 'Semua Wali santri', '2018-03-04', 'Himbauan', '  Kepada Seluruh Wali santri, Hari ini sudah masuk tanggal 10 Agustus 2017, Bagi yang belum melunasi SPP Bulan Agustus 2017, Harap segera melunasi. Bagi yang yang telah membayar, Harap abaikan berita ini, dan kami ucapkan Jazakumullohu Khoiron, ', 'Bag. Keuangan', '0'),
(7, '', '2018-03-05', '', 'Silahkan isi komentar anda', '', '0'),
(8, 'Semua Wali Santri', '2018-04-01', 'Liburan', 'Diberitahukan Bahwasannya Liburan Semester Ini Akan Dimulai Tanggal 10 Juni 2018 Sampai 25 Juni 2018. Terima Kasih Atas Perhatiannya', 'Mudir Pondok', '0'),
(9, 'Semua Wali Santri', '2018-04-30', 'Liburan', 'Diharapkan melunasi SPP Bulan Ini', 'Mudir Pondok', '0');

-- --------------------------------------------------------

--
-- Table structure for table `groups`
--

CREATE TABLE `groups` (
  `id` mediumint(8) UNSIGNED NOT NULL,
  `name` varchar(20) NOT NULL,
  `description` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `groups`
--

INSERT INTO `groups` (`id`, `name`, `description`) VALUES
(1, 'admin', 'Administrator'),
(2, 'members', 'General User');

-- --------------------------------------------------------

--
-- Table structure for table `isiformulir`
--

CREATE TABLE `isiformulir` (
  `nopendaftaran` int(11) NOT NULL,
  `edit` varchar(10) NOT NULL,
  `lokasitest` varchar(50) NOT NULL,
  `tanggalmasuk` date NOT NULL,
  `marhalah` varchar(50) NOT NULL,
  `kelas` varchar(20) NOT NULL,
  `uangpangkal` int(11) NOT NULL,
  `spp` int(11) NOT NULL,
  `namasiswa` varchar(200) NOT NULL,
  `kotalahir` varchar(100) NOT NULL,
  `tanggallahir` date NOT NULL,
  `jeniskelamin` varchar(20) NOT NULL,
  `niksiswa` varchar(50) NOT NULL,
  `hobi` varchar(100) NOT NULL,
  `citacita` varchar(100) NOT NULL,
  `jumlahsaudara` int(11) NOT NULL,
  `tbbb` varchar(50) NOT NULL,
  `riwayatsakit` varchar(100) NOT NULL,
  `golongandarah` varchar(10) NOT NULL,
  `jenistempattinggal` varchar(50) NOT NULL,
  `alamat` varchar(200) NOT NULL,
  `kecamatan` varchar(50) NOT NULL,
  `kabupaten` varchar(50) NOT NULL,
  `provinsi` varchar(50) NOT NULL,
  `asalsekolah` varchar(100) NOT NULL,
  `kelasasal` varchar(10) NOT NULL,
  `jurusan` varchar(50) NOT NULL,
  `rata2rapor` varchar(10) NOT NULL,
  `nilaimatematika` varchar(10) NOT NULL,
  `nilaiipa` varchar(10) NOT NULL,
  `jenispendidikan` varchar(50) NOT NULL,
  `npsnlembaga` varchar(50) NOT NULL,
  `namalembaga` varchar(50) NOT NULL,
  `kabupatenlembaga` varchar(50) NOT NULL,
  `provinsilembaga` varchar(50) NOT NULL,
  `tahunlulus` varchar(20) NOT NULL,
  `statusijasah` varchar(50) NOT NULL,
  `nokk` varchar(20) NOT NULL,
  `nokks` varchar(20) NOT NULL,
  `nokartupkh` varchar(20) NOT NULL,
  `namaayah` varchar(50) NOT NULL,
  `statushidupayah` varchar(50) NOT NULL,
  `noktpayah` varchar(50) NOT NULL,
  `pendidikanayah` varchar(50) NOT NULL,
  `pekerjaanayah` varchar(50) NOT NULL,
  `nohpayah` varchar(50) NOT NULL,
  `gaji` double NOT NULL,
  `namaibu` varchar(50) NOT NULL,
  `statushidupibu` varchar(50) NOT NULL,
  `noktpibu` varchar(50) NOT NULL,
  `pendidikanibu` varchar(50) NOT NULL,
  `pekerjaanibu` varchar(50) NOT NULL,
  `nohpibu` varchar(50) NOT NULL,
  `namawali` varchar(50) NOT NULL,
  `hubungan` varchar(50) NOT NULL,
  `noktpwali` varchar(50) NOT NULL,
  `pendidikanwali` varchar(50) NOT NULL,
  `pekerjaanwali` varchar(50) NOT NULL,
  `gajiwali` double NOT NULL,
  `nokip` varchar(20) NOT NULL,
  `statuspip` varchar(50) NOT NULL,
  `alasanpip` varchar(50) NOT NULL,
  `periodepip` varchar(20) NOT NULL,
  `bidangprestasi` varchar(50) NOT NULL,
  `tingkatprestasi` varchar(20) NOT NULL,
  `peringkat` varchar(20) NOT NULL,
  `tahunprestasi` varchar(20) NOT NULL,
  `statusbeasiswa` varchar(50) NOT NULL,
  `sumberbeasiswa` varchar(50) NOT NULL,
  `jenisbeasiswa` varchar(50) NOT NULL,
  `waktubulan` varchar(50) NOT NULL,
  `besaranuang` varchar(20) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Dumping data for table `isiformulir`
--

INSERT INTO `isiformulir` (`nopendaftaran`, `edit`, `lokasitest`, `tanggalmasuk`, `marhalah`, `kelas`, `uangpangkal`, `spp`, `namasiswa`, `kotalahir`, `tanggallahir`, `jeniskelamin`, `niksiswa`, `hobi`, `citacita`, `jumlahsaudara`, `tbbb`, `riwayatsakit`, `golongandarah`, `jenistempattinggal`, `alamat`, `kecamatan`, `kabupaten`, `provinsi`, `asalsekolah`, `kelasasal`, `jurusan`, `rata2rapor`, `nilaimatematika`, `nilaiipa`, `jenispendidikan`, `npsnlembaga`, `namalembaga`, `kabupatenlembaga`, `provinsilembaga`, `tahunlulus`, `statusijasah`, `nokk`, `nokks`, `nokartupkh`, `namaayah`, `statushidupayah`, `noktpayah`, `pendidikanayah`, `pekerjaanayah`, `nohpayah`, `gaji`, `namaibu`, `statushidupibu`, `noktpibu`, `pendidikanibu`, `pekerjaanibu`, `nohpibu`, `namawali`, `hubungan`, `noktpwali`, `pendidikanwali`, `pekerjaanwali`, `gajiwali`, `nokip`, `statuspip`, `alasanpip`, `periodepip`, `bidangprestasi`, `tingkatprestasi`, `peringkat`, `tahunprestasi`, `statusbeasiswa`, `sumberbeasiswa`, `jenisbeasiswa`, `waktubulan`, `besaranuang`) VALUES
(1, 'yes', 'BANYUMAS, UST. AMIN TAUFIQ', '0000-00-00', '', '', 0, 0, 'achmad yahdi', 'tangerang', '2009-04-05', 'Laki-Laki', '321321', '3132', '231', 231, '231', '31', 'A', 'Rumah Sendiri', 'piyungan', '21', '3', 'Jawa Barat', 'smk yupentek', '3', 'listrik', '80', '80', '80', 'sma', '098098098098', 'smk yupuentek', 'tangerang', 'jawabarat', '1928', 'asli tapi asli', '123456', '456789', '159753', 'tantan', 'hidup', '1523164645', 'SLTA', 'swasta', '0845654548456', 2000000, 'Nurliyah', 'Rohimahallah', '-', 'SLTA', '-', '-', 'Tantan', 'Ayah', '65465464654', 'SLTA', '', 2500000, '15', '321313', 'tidak ada', 'mei 2018', 'tahfidz', 'kabupaten', '2', '2017', 'aktif', 'pemda', 'tetap', '12', '2000000'),
(2, '', '', '0000-00-00', '', '', 0, 0, '', '', '0000-00-00', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', ''),
(3, 'no', '', '0000-00-00', '', '', 0, 0, '', '', '0000-00-00', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', ''),
(4, '', '', '0000-00-00', '', '', 0, 0, '', '', '0000-00-00', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '');

-- --------------------------------------------------------

--
-- Table structure for table `isiformulirasli`
--

CREATE TABLE `isiformulirasli` (
  `nopendaftaran` int(11) NOT NULL,
  `namasiswa` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `kotalahir` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `tanggallahir` date DEFAULT NULL,
  `jeniskelamin` varchar(20) CHARACTER SET utf8 DEFAULT NULL,
  `anakke` varchar(5) CHARACTER SET utf8 DEFAULT NULL,
  `bersaudara` varchar(5) CHARACTER SET utf8 DEFAULT NULL,
  `golongandarah` varchar(2) CHARACTER SET utf8 DEFAULT NULL,
  `marhalah` varchar(50) CHARACTER SET utf8 NOT NULL,
  `kelas` varchar(10) CHARACTER SET utf8 DEFAULT NULL,
  `spp` varchar(20) CHARACTER SET utf8 DEFAULT NULL,
  `nokk` varchar(50) CHARACTER SET utf8 NOT NULL,
  `email` varchar(100) CHARACTER SET utf8 NOT NULL,
  `ttlayah` varchar(200) CHARACTER SET utf8 NOT NULL,
  `noktpayah` varchar(50) CHARACTER SET utf8 NOT NULL,
  `pendidikanayah` varchar(200) CHARACTER SET utf8 NOT NULL,
  `gajiayah` double NOT NULL,
  `namaayah` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `pekerjaanayah` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `ttlibu` varchar(200) CHARACTER SET utf8 NOT NULL,
  `noktpibu` varchar(100) CHARACTER SET utf8 NOT NULL,
  `pendidikanibu` varchar(200) CHARACTER SET utf8 NOT NULL,
  `gajiibu` double NOT NULL,
  `namaibu` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `pekerjaanibu` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `alamat` varchar(200) CHARACTER SET utf8 NOT NULL,
  `kelurahan` varchar(100) CHARACTER SET utf8 NOT NULL,
  `kecamatan` varchar(100) CHARACTER SET utf8 NOT NULL,
  `alamatkota` varchar(150) CHARACTER SET utf8 DEFAULT NULL,
  `provinsi` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `telephon` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `telephonrumah` varchar(50) CHARACTER SET utf8 NOT NULL,
  `asalsekolah` varchar(150) CHARACTER SET utf8 DEFAULT NULL,
  `alamatsekolah` varchar(150) CHARACTER SET utf8 DEFAULT NULL,
  `tanggalmasuk` datetime DEFAULT NULL,
  `noinduk` varchar(200) CHARACTER SET utf8 DEFAULT NULL,
  `ijasah` varchar(60) CHARACTER SET utf8 DEFAULT NULL,
  `akte` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `skhun` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `nisn` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `uangpangkal` double DEFAULT '0',
  `lokasitest` varchar(100) CHARACTER SET utf8 NOT NULL,
  `edit` varchar(10) CHARACTER SET utf8 NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `isiformulirasli`
--

INSERT INTO `isiformulirasli` (`nopendaftaran`, `namasiswa`, `kotalahir`, `tanggallahir`, `jeniskelamin`, `anakke`, `bersaudara`, `golongandarah`, `marhalah`, `kelas`, `spp`, `nokk`, `email`, `ttlayah`, `noktpayah`, `pendidikanayah`, `gajiayah`, `namaayah`, `pekerjaanayah`, `ttlibu`, `noktpibu`, `pendidikanibu`, `gajiibu`, `namaibu`, `pekerjaanibu`, `alamat`, `kelurahan`, `kecamatan`, `alamatkota`, `provinsi`, `telephon`, `telephonrumah`, `asalsekolah`, `alamatsekolah`, `tanggalmasuk`, `noinduk`, `ijasah`, `akte`, `skhun`, `nisn`, `uangpangkal`, `lokasitest`, `edit`) VALUES
(1, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '', NULL, NULL, '', '', '', '', '', 0, NULL, NULL, '', '', '', 0, NULL, NULL, '', '', '', NULL, NULL, NULL, '', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, '', ''),
(2, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '', NULL, NULL, '', '', '', '', '', 0, NULL, NULL, '', '', '', 0, NULL, NULL, '', '', '', NULL, NULL, NULL, '', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, '', 'yes'),
(3, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '', NULL, NULL, '', '', '', '', '', 0, NULL, NULL, '', '', '', 0, NULL, NULL, '', '', '', NULL, NULL, NULL, '', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, '', 'yes'),
(4, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '', NULL, NULL, '', '', '', '', '', 0, NULL, NULL, '', '', '', 0, NULL, NULL, '', '', '', NULL, NULL, NULL, '', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, '', '');

-- --------------------------------------------------------

--
-- Table structure for table `izin`
--

CREATE TABLE `izin` (
  `nourut` int(11) NOT NULL,
  `nis` varchar(20) NOT NULL,
  `tanggalizin` date NOT NULL,
  `tanggalkembali` date NOT NULL,
  `penjemput` varchar(200) NOT NULL,
  `catatan` varchar(200) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `izin`
--

INSERT INTO `izin` (`nourut`, `nis`, `tanggalizin`, `tanggalkembali`, `penjemput`, `catatan`) VALUES
(1, '11700025', '2018-02-20', '0000-00-00', 'ibunya', 'tidak ada catatan'),
(2, '11700025', '2018-02-20', '0000-00-00', 'adadf', 'asfasdf'),
(3, '11700025', '2018-02-20', '0000-00-00', 'sdfg', 'abcdef'),
(4, '11700025', '2018-02-20', '0000-00-00', 'AADSFASF', 'ASDFASD'),
(5, '11700026', '2018-02-20', '0000-00-00', 'ahmad yahdi', 'ASDFASD'),
(6, '11700025', '2018-02-20', '0000-00-00', 'ahmad yahdi', 'tidak ada catatan'),
(7, '11700025', '2018-02-20', '0000-00-00', 'ahmad yahdi', 'tidak ada catatan'),
(8, '11700025', '2018-02-20', '0000-00-00', 'ahmad yahdi', 'tidak ada catatan'),
(9, '11700024', '2018-02-20', '0000-00-00', 'ahmad yahdi', 'tidak ada catatan'),
(10, '11700025', '2018-02-20', '0000-00-00', 'ahmad yahdi', 'tidak ada catatan'),
(11, '11700025', '2018-02-20', '0000-00-00', 'ahmad yahdi', 'tidak ada catatan'),
(12, '', '2018-02-21', '0000-00-00', '', ''),
(13, '11700025', '2018-02-21', '0000-00-00', '', ''),
(14, '11700025', '2018-02-21', '0000-00-00', '', ''),
(15, '11700025', '2018-02-21', '0000-00-00', 'aaa', 'aaaa'),
(16, '11700024', '2018-02-21', '0000-00-00', 'tidak ada', 'aaaaaaaaa'),
(17, '', '2018-02-21', '0000-00-00', '', ''),
(18, '', '2018-02-21', '0000-00-00', '', ''),
(19, '', '2018-02-21', '0000-00-00', '', ''),
(20, '', '2018-02-21', '0000-00-00', '', ''),
(21, '11700025', '2018-02-22', '0000-00-00', 'ahmad yahdi', 'tidak ada catatan'),
(22, '11700025', '2018-02-24', '0000-00-00', '', ''),
(23, '11700025', '2018-03-01', '0000-00-00', 'ahmad yahdi', 'ASDFASD'),
(25, '11700027', '2018-03-03', '0000-00-00', 'ahmad yahdi', 'tidak ada catatan'),
(26, '11700025', '2018-03-03', '0000-00-00', 'ahmad yahdi', 'tidak ada catatan'),
(27, '11700024', '2018-03-03', '0000-00-00', 'ahmad yahdi', 'tidak ada catatan'),
(28, '11700027', '2018-03-03', '0000-00-00', 'ahmad yahdi', 'alkdsfalksjdf'),
(29, '11700025', '2018-03-03', '0000-00-00', 'ahmad yahdi', 'alkdsfalksjdf'),
(30, '11700024', '2018-03-03', '0000-00-00', 'ahmad yahdi', 'tidak ada catatan'),
(31, '11700025', '2018-03-03', '0000-00-00', 'ibunya', 'asdf'),
(32, '11700025', '2018-03-03', '0000-00-00', 'ibunya', 'asdf'),
(33, '11700025', '2018-03-03', '0000-00-00', 'ibunya', 'asdf'),
(34, '11700025', '2018-03-03', '0000-00-00', 'AADSFASF', 'ASDF'),
(35, '11700027', '2018-03-03', '0000-00-00', 'ahmad yahdi', 'asdf'),
(36, '11700025', '2018-03-03', '0000-00-00', 'ibunya', 'ASDF'),
(37, '11700027', '2018-04-01', '0000-00-00', 'Ibunya', 'Berobat Ke Rumah Sakit selama 1 Hari'),
(38, '11700025', '2018-04-18', '0000-00-00', 'ayahnya', 'ke kota'),
(39, '11700025', '2018-04-18', '0000-00-00', 'ayahnya', 'ke kota'),
(40, '', '2018-04-18', '0000-00-00', '', ''),
(41, '11700038', '2018-04-18', '0000-00-00', '', ''),
(42, '11700051', '2018-04-18', '0000-00-00', 'sdasd', 'dsad'),
(43, '11700051', '2018-04-18', '0000-00-00', 'sdasd', 'dsad'),
(44, '11700051', '2018-04-18', '0000-00-00', 'sdasd', 'dsad'),
(45, '', '2018-04-18', '0000-00-00', '', ''),
(46, '', '2018-04-18', '0000-00-00', '', ''),
(47, '', '2018-04-18', '0000-00-00', '', ''),
(48, '', '2018-04-18', '0000-00-00', '', ''),
(49, '', '2018-04-18', '0000-00-00', '', ''),
(50, '', '2018-04-21', '0000-00-00', '', ''),
(51, '', '2018-04-21', '0000-00-00', '', ''),
(52, '', '2018-04-25', '0000-00-00', '', ''),
(53, '11700025', '2018-04-30', '0000-00-00', 'Orang Tuanya', 'Izi ke kota'),
(54, '11700024', '2018-04-30', '0000-00-00', 'ibunya', 'tidak ada catatan'),
(55, '11700026', '2018-04-30', '0000-00-00', 'kbjbjhgg', 'ljjkjn'),
(56, '11700026', '2018-04-30', '0000-00-00', 'lkdkjvnsk', 'asda'),
(57, '11700026', '2018-04-30', '0000-00-00', 'sdfsdf', 'sdfsdf'),
(58, '11700026', '2018-04-30', '0000-00-00', 'sdfsdfs', 'sdfsdf'),
(59, '11700024', '2018-04-30', '0000-00-00', 'dsd', 'ds'),
(60, '11700038', '2018-04-30', '0000-00-00', 'dsd', 'dsddsd'),
(61, '11700073', '2018-04-30', '0000-00-00', 'sdsdsdsd', 'sdsd'),
(62, '11700024', '2018-04-30', '0000-00-00', 'ii', 'lll'),
(64, '11700039', '2018-05-01', '0000-00-00', 'sdfg', 'sdfg'),
(65, '11700078', '2018-05-01', '0000-00-00', 'asd', 'dsd'),
(66, '11700073', '2018-05-01', '0000-00-00', 'g', 'rtrt'),
(67, '11700075', '2018-05-01', '0000-00-00', 'ghgnh', 'hgjghj'),
(68, '11700078', '2018-05-01', '0000-00-00', 'ukuku', 'kuk'),
(69, '11700074', '2018-05-01', '0000-00-00', 'jmjh', 'jhjm'),
(70, '11700074', '2018-05-01', '0000-00-00', 'ghghg', 'gh'),
(71, '11700073', '2018-05-01', '0000-00-00', 'ewe', 'wewe'),
(72, '11700074', '2018-05-01', '0000-00-00', 'hgh', 'ghgh'),
(73, '11700039', '2018-05-01', '0000-00-00', 'asdasf', 'sdfdsfds'),
(74, '11700075', '2018-05-01', '0000-00-00', 'ss', 'sdsd'),
(75, '11700039', '2018-05-01', '0000-00-00', 'orang2 tuanya', ''),
(76, '11700078', '2018-05-01', '0000-00-00', 'rerer', 'erer'),
(77, '11700074', '2018-05-01', '0000-00-00', 'fdf', 'fdf'),
(78, '11700074', '2018-05-01', '0000-00-00', 'rer', 'rer'),
(79, '11700075', '2018-05-01', '0000-00-00', 'fsfs', 'fsf'),
(80, '11700077', '2018-05-01', '0000-00-00', '', 'dsd'),
(81, '11700039', '2018-05-01', '0000-00-00', 'asdasd', 'asdas'),
(82, '11700073', '2018-05-01', '0000-00-00', 'as', 'sas'),
(83, '11700078', '2018-05-01', '0000-00-00', 'dsds', 'sds'),
(84, '11700077', '2018-05-01', '0000-00-00', 'sdsd', 'dsd'),
(85, '11700039', '2018-05-01', '0000-00-00', 'sdfsd', 'sdfsdf'),
(86, '11700078', '2018-06-01', '0000-00-00', 'wsdsd', 'sdsd'),
(87, '11700039', '2018-05-01', '0000-00-00', 'sdfdsd', 'sdfsdf'),
(88, '11700074', '2018-05-01', '0000-00-00', 'das', 'dsd'),
(89, '11700075', '2018-05-01', '0000-00-00', 'dsd', 'sd'),
(90, '11700079', '2018-05-01', '0000-00-00', 'dsd', 'dsd'),
(91, '11700073', '2018-05-01', '0000-00-00', 'sdsd', 'dsd'),
(92, '11700074', '2018-05-01', '0000-00-00', 'dsds', 'dsad'),
(93, '11700039', '2018-05-01', '0000-00-00', 'sdfdsf', 'sdfs'),
(94, '11700074', '2018-05-01', '0000-00-00', 'sdd', 'sdfs'),
(95, '11700077', '2018-05-01', '0000-00-00', 'dsd', 'dsd'),
(96, '11700078', '2018-05-10', '0000-00-00', 'ds', 'dsdsd'),
(97, '11700089', '2018-05-04', '0000-00-00', 'fdf', 'fdf'),
(99, '11700090', '2018-05-16', '0000-00-00', 'ghgh', 'ghgh'),
(100, '11700090', '2018-05-16', '0000-00-00', 'ghgh', 'ghgh'),
(122, '11700094', '2018-05-03', '0000-00-00', 'Ibunya', 'tidak ada catatan'),
(123, '11700108', '2018-05-03', '0000-00-00', 'Ayahnya', 'tidak ada'),
(124, '11700070', '2018-05-22', '0000-00-00', 'Pamannya', 'Ke rumah Saudaranya'),
(125, '11700094', '2018-05-18', '0000-00-00', 'Pamannya', 'Pulang 1 Hari'),
(126, '11700093', '2018-05-22', '0000-00-00', 'sds', 'dsd'),
(127, '11700070', '2018-05-22', '0000-00-00', 'ghgnh', 'dsd');

-- --------------------------------------------------------

--
-- Table structure for table `jurnal`
--

CREATE TABLE `jurnal` (
  `nourut` double NOT NULL,
  `tanggal` date NOT NULL,
  `nonota` varchar(50) NOT NULL,
  `koderekening` double NOT NULL,
  `debet` double NOT NULL,
  `kredit` double NOT NULL,
  `keterangan` varchar(250) NOT NULL,
  `pengguna` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `jurnal`
--

INSERT INTO `jurnal` (`nourut`, `tanggal`, `nonota`, `koderekening`, `debet`, `kredit`, `keterangan`, `pengguna`) VALUES
(2, '2018-05-18', '2', 400002, 0, 1000000, '11700070', 'kosongan'),
(3, '2018-05-18', '2', 100099, 1000000, 0, '11700070', 'kosongan'),
(6, '2018-05-18', '3', 400002, 0, 20000, '11700091', 'aaaaa'),
(7, '2018-05-18', '3', 100099, 20000, 0, '11700091', 'aaaaa'),
(8, '2018-05-18', '4', 400002, 0, 1000000, '11700093', 'aaaaa'),
(9, '2018-05-18', '4', 100099, 1000000, 0, '11700093', 'aaaaa'),
(10, '2018-05-19', '1', 100099, 0, 0, '11700093', 'aaaaa'),
(11, '2018-05-19', '2', 100099, 0, 0, '11700093', 'aaaaa'),
(12, '2018-05-19', '3', 100099, 0, 0, '11700070', 'aaaaa'),
(13, '2018-05-19', '5', 100100, 100000, 0, '', 'admin'),
(14, '2018-05-19', '5', 200001, 10000, 0, '', 'admin'),
(15, '2018-05-19', '5', 200001, 0, 110000, 'testing', 'admin'),
(16, '2018-05-19', '6', 100100, 0, 1000, '', 'admin'),
(17, '2018-05-19', '6', 100100, 0, 10000, '', 'admin'),
(18, '2018-05-19', '6', 100100, 11000, 0, 'asdasd', 'admin'),
(19, '2018-05-19', '1', 100099, 0, 0, '11700108', 'aaaaa'),
(20, '2018-05-20', '2', 400002, 0, 100000, '11700108', 'aaaaa'),
(21, '2018-05-20', '2', 100099, 100000, 0, '11700108', 'aaaaa'),
(22, '2018-05-20', '3', 400002, 0, 200000, '11700094', 'aaaaa'),
(23, '2018-05-20', '3', 200001, 200000, 0, '11700094', 'aaaaa'),
(24, '2018-05-20', '7', 600009, 0, 200000, '', 'admin'),
(25, '2018-05-20', '7', 600011, 0, 100000, '', 'admin'),
(26, '2018-05-20', '7', 600011, 300000, 0, 'Infaq', 'admin'),
(27, '2018-05-21', '4', 600000, 0, 1000000, 'SPP Bulan januari', 'aaaaa'),
(28, '2018-05-21', '4', 600000, 0, 1000000, 'SPP Bulan februari', 'aaaaa'),
(29, '2018-05-21', '4', 100099, 2000000, 0, '11700094', 'aaaaa'),
(30, '2018-05-21', '5', 600000, 0, 1000000, 'SPP Bulan januari', 'aaaaa'),
(31, '2018-05-21', '5', 600000, 0, 1000000, 'SPP Bulan februari', 'aaaaa'),
(32, '2018-05-21', '5', 600001, 0, 500000, '11700093', 'aaaaa'),
(33, '2018-05-21', '5', 100099, 2500000, 0, '11700093', 'aaaaa'),
(34, '2018-05-21', '6', 600000, 0, 1000000, 'SPP Bulan januari', 'aaaaa'),
(35, '2018-05-21', '6', 600000, 0, 1000000, 'SPP Bulan februari', 'aaaaa'),
(36, '2018-05-21', '6', 600001, 0, 500000, '11700070', 'aaaaa'),
(37, '2018-05-21', '6', 100099, 2500000, 0, '11700070', 'aaaaa'),
(38, '2018-05-21', '7', 600000, 0, 1000000, 'SPP Bulan januari', 'aaaaa'),
(39, '2018-05-21', '7', 600000, 0, 1000000, 'SPP Bulan februari', 'aaaaa'),
(40, '2018-05-21', '7', 600001, 0, 200000, '11700094', 'aaaaa'),
(41, '2018-05-21', '7', 100099, 2200000, 0, '11700094', 'aaaaa'),
(42, '2018-05-21', '8', 600000, 0, 1000000, 'SPP Bulan januari', 'aaaaa'),
(43, '2018-05-21', '8', 600000, 0, 1000000, 'SPP Bulan februari', 'aaaaa'),
(44, '2018-05-21', '8', 600001, 0, 100000, '11700094', 'aaaaa'),
(45, '2018-05-21', '8', 100099, 2100000, 0, '11700094', 'aaaaa');

-- --------------------------------------------------------

--
-- Table structure for table `kelas`
--

CREATE TABLE `kelas` (
  `nourut` int(11) NOT NULL,
  `namakelas` varchar(10) NOT NULL,
  `marhalah` varchar(50) NOT NULL,
  `walikelas` varchar(100) NOT NULL,
  `putraputri` varchar(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `kelas`
--

INSERT INTO `kelas` (`nourut`, `namakelas`, `marhalah`, `walikelas`, `putraputri`) VALUES
(2, 'I.B', 'SD', 'ACHMAD YACHDI FAUZAN, S.T.', 'Putri'),
(3, 'I.C', 'SD', ' rnACHMAD YACHDI FAUZAN, S.T.', 'Putra'),
(4, 'II.A', 'SD', 'ACHMAD YACHDI FAUZAN, S.T.', 'Putra'),
(5, 'II.B', 'SD', 'ACHMAD YACHDI FAUZAN, S.T.', 'Putri'),
(6, 'III.A', 'SD', 'ACHMAD YACHDI FAUZAN, S.T.', 'Putra'),
(7, 'III.B', 'SD', 'ACHMAD YACHDI FAUZAN, S.T.', 'Putri'),
(8, 'IV.A', 'SD', 'ACHMAD YACHDI FAUZAN, S.T.', 'Putra'),
(9, 'IV.B', 'SD', 'ACHMAD YACHDI FAUZAN, S.T.', 'Putri'),
(10, 'IX.A', 'SLTP', 'ACHMAD YACHDI FAUZAN, S.T.', 'Putra'),
(11, 'IX.B', 'SLTP', 'ACHMAD YACHDI FAUZAN, S.T.', 'Putra'),
(12, 'IX.C', 'SLTP', 'ACHMAD YACHDI FAUZAN, S.T.', 'Putra'),
(13, 'IX.D', 'SLTP', 'ACHMAD YACHDI FAUZAN, S.T.', 'Putra'),
(14, 'IX.E', 'SLTP', 'ACHMAD YACHDI FAUZAN, S.T.', 'Putra'),
(15, 'IX.F', 'SLTP', 'ACHMAD YACHDI FAUZAN, S.T.', 'Putri'),
(16, 'IX.G', 'SLTP', 'ACHMAD YACHDI FAUZAN, S.T.', 'Putri'),
(17, 'IX.H', 'SLTP', 'ACHMAD YACHDI FAUZAN, S.T.', 'Putri'),
(18, 'IX.I', 'SLTP', 'ACHMAD YACHDI FAUZAN, S.T.', 'Putri'),
(19, 'IX.J', 'SLTP', 'ACHMAD YACHDI FAUZAN, S.T.', 'Putri'),
(21, 'V.A', 'SD', 'ACHMAD YACHDI FAUZAN, S.T.', 'Putra'),
(22, 'V.B', 'SD', 'ACHMAD YACHDI FAUZAN, S.T.', 'Putri'),
(23, 'VI.A', 'SD', 'ACHMAD YACHDI FAUZAN, S.T.', 'Putra'),
(24, 'VI.B', 'SD', 'ACHMAD YACHDI FAUZAN, S.T.', 'Putri'),
(25, 'VII.A', 'SLTP', 'ACHMAD YACHDI FAUZAN, S.T.', 'Putra'),
(26, 'VII.B', 'SLTP', 'ACHMAD YACHDI FAUZAN, S.T.', 'Putra'),
(27, 'VII.C', 'SLTP', 'ACHMAD YACHDI FAUZAN, S.T.', 'Putra'),
(28, 'VII.D', 'SLTP', 'ACHMAD YACHDI FAUZAN, S.T.', 'Putra'),
(29, 'VII.E', 'SLTP', 'ACHMAD YACHDI FAUZAN, S.T.', 'Putra'),
(30, 'VII.F', 'SLTP', 'ACHMAD YACHDI FAUZAN, S.T.', 'Putri'),
(31, 'VII.G', 'SLTP', 'ACHMAD YACHDI FAUZAN, S.T.', 'Putri'),
(32, 'VII.H', 'SLTP', 'ACHMAD YACHDI FAUZAN, S.T.', 'Putri'),
(33, 'VII.I', 'SLTP', 'ACHMAD YACHDI FAUZAN, S.T.', 'Putri'),
(34, 'VII.J', 'SLTP', 'ACHMAD YACHDI FAUZAN, S.T.', 'Putri'),
(35, 'VIII.A', 'SLTP', 'ACHMAD YACHDI FAUZAN, S.T.', 'Putra'),
(36, 'VIII.B', 'SLTP', 'ACHMAD YACHDI FAUZAN, S.T.', 'Putra'),
(37, 'VIII.C', 'SLTP', 'ACHMAD YACHDI FAUZAN, S.T.', 'Putra'),
(38, 'VIII.D', 'SLTP', 'ACHMAD YACHDI FAUZAN, S.T.', 'Putra'),
(39, 'VIII.E', 'SLTP', 'ACHMAD YACHDI FAUZAN, S.T.', 'Putra'),
(40, 'VIII.F', 'SLTP', 'ACHMAD YACHDI FAUZAN, S.T.', 'Putri'),
(41, 'VIII.G', 'SLTP', 'ACHMAD YACHDI FAUZAN, S.T.', 'Putri'),
(42, 'VIII.H', 'SLTP', 'ACHMAD YACHDI FAUZAN, S.T.', 'Putri'),
(43, 'VIII.I', 'SLTP', 'ACHMAD YACHDI FAUZAN, S.T.', 'Putri'),
(44, 'VIII.J', 'SLTP', 'ACHMAD YACHDI FAUZAN, S.T.', 'Putri'),
(45, 'X.A', 'SLTA', 'ACHMAD YACHDI FAUZAN, S.T.', 'Putra'),
(46, 'X.B', 'SLTA', 'ACHMAD YACHDI FAUZAN, S.T.', 'Putra'),
(47, 'X.C', 'SLTA', 'ACHMAD YACHDI FAUZAN, S.T.', 'Putra'),
(48, 'X.D', 'SLTA', 'ACHMAD YACHDI FAUZAN, S.T.', 'Putra'),
(49, 'X.E', 'SLTA', 'ACHMAD YACHDI FAUZAN, S.T.', 'Putri'),
(50, 'X.F', 'SLTA', 'ACHMAD YACHDI FAUZAN, S.T.', 'Putri'),
(51, 'X.G', 'SLTA', 'ACHMAD YACHDI FAUZAN, S.T.', 'Putri'),
(52, 'X.H', 'SLTA', 'ACHMAD YACHDI FAUZAN, S.T.', 'Putri'),
(53, 'XI.A', 'SLTA', 'ACHMAD YACHDI FAUZAN, S.T.', 'Putra'),
(54, 'XI.B', 'SLTA', 'ACHMAD YACHDI FAUZAN, S.T.', 'Putra'),
(55, 'XI.C', 'SLTA', 'ACHMAD YACHDI FAUZAN, S.T.', 'Putra'),
(56, 'XI.D', 'SLTA', 'ACHMAD YACHDI FAUZAN, S.T.', 'Putra'),
(57, 'XI.E', 'SLTA', 'ACHMAD YACHDI FAUZAN, S.T.', 'Putri'),
(58, 'XI.F', 'SLTA', 'ACHMAD YACHDI FAUZAN, S.T.', 'Putri'),
(59, 'XI.G', 'SLTA', 'ACHMAD YACHDI FAUZAN, S.T.', 'Putri'),
(60, 'XI.H', 'SLTA', 'ACHMAD YACHDI FAUZAN, S.T.', 'Putri'),
(61, 'XII.A', 'SLTA', 'ACHMAD YACHDI FAUZAN, S.T.', 'Putra'),
(62, 'XII.B', 'SLTA', 'ACHMAD YACHDI FAUZAN, S.T.', 'Putra'),
(63, 'XII.C', 'SLTA', 'ACHMAD YACHDI FAUZAN, S.T.', 'Putra'),
(64, 'XII.D', 'SLTA', 'ACHMAD YACHDI FAUZAN, S.T.', 'Putra'),
(65, 'XII.E', 'SLTA', 'ACHMAD YACHDI FAUZAN, S.T.', 'Putri'),
(66, 'XII.F', 'SLTA', 'ACHMAD YACHDI FAUZAN, S.T.', 'Putri'),
(67, 'XII.G', 'SLTA', 'ACHMAD YACHDI FAUZAN, S.T.', 'Putri'),
(68, 'XII.H', 'SLTA', 'ACHMAD YACHDI FAUZAN, S.T.', 'Putri'),
(69, 'I.A', 'SD', 'ACHMAD YACHDI FAUZAN, S.T.', 'Putra'),
(70, 'X.A', 'ALIYAH', '', ''),
(71, 'X.B', 'ALIYAH', '', '');

-- --------------------------------------------------------

--
-- Table structure for table `kesehatan`
--

CREATE TABLE `kesehatan` (
  `nourut` double NOT NULL,
  `tanggal` date DEFAULT NULL,
  `nis` varchar(15) DEFAULT NULL,
  `keluhan` varchar(200) DEFAULT NULL,
  `obat` varchar(200) DEFAULT NULL,
  `catatan` varchar(200) DEFAULT NULL,
  `keparahan` varchar(50) DEFAULT NULL,
  `pengguna` varchar(200) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Dumping data for table `kesehatan`
--

INSERT INTO `kesehatan` (`nourut`, `tanggal`, `nis`, `keluhan`, `obat`, `catatan`, `keparahan`, `pengguna`) VALUES
(27, '2018-02-10', '10233022223', 'asdf', 'asdf', 'asdf', NULL, ''),
(28, '2018-02-10', '10422020012', 'asdf', 'asdf', 'asdf', NULL, ''),
(32, '2018-03-03', '11700027', 'Pusing Pusing', 'Paramex', 'tidak ada catatan', NULL, ''),
(31, NULL, NULL, NULL, NULL, NULL, NULL, ''),
(33, '2018-04-01', '11700027', 'Pusing Pusing', 'Paramex', 'Berobat Ke Rumah Sakit selama 1 Hari', NULL, ''),
(34, '2018-04-01', '11700024', 'Pusing Pusing', 'Paramex', 'Berobat Ke Rumah Sakit selama 1 Hari', NULL, ''),
(35, '2021-04-18', '', '', '', '', NULL, ''),
(36, '2021-04-18', '', '', '', '', NULL, ''),
(37, '2021-04-18', '', '', '', '', NULL, ''),
(38, '2021-04-18', '', '', '', '', NULL, ''),
(39, '2021-04-18', '', '', '', '', NULL, ''),
(40, '2021-04-18', '', '', '', '', NULL, ''),
(41, '2021-04-18', '', '', '', '', NULL, ''),
(42, '2021-04-18', '', '', '', '', NULL, ''),
(43, '2021-04-18', '', '', '', '', NULL, ''),
(44, '2021-04-18', '', '', '', '', NULL, ''),
(45, '2021-04-18', '', '', '', '', NULL, ''),
(46, '2021-04-18', '', '', '', '', NULL, ''),
(47, '2021-04-18', '', '', '', '', NULL, ''),
(48, '2021-04-18', '', '', '', '', NULL, ''),
(49, '2018-04-18', '', '', '', '', NULL, ''),
(50, '2018-04-18', '', '', '', '', NULL, ''),
(51, '2018-04-18', '', '', '', '', NULL, ''),
(52, '2018-04-18', '', '', '', '', NULL, ''),
(53, '2018-04-18', '', '', '', '', NULL, ''),
(54, '2018-04-18', '', '', '', '', NULL, ''),
(55, '2018-04-18', '', '', '', '', NULL, ''),
(56, '2018-04-18', '', '', '', '', NULL, ''),
(57, '2018-04-18', '11700024', '', '', '', NULL, ''),
(58, '2018-04-18', '', '', '', '', NULL, ''),
(59, '2018-04-18', '', '', '', '', NULL, ''),
(60, '2018-04-18', '', '', '', '', NULL, ''),
(61, '2018-04-18', '', '', '', '', NULL, ''),
(62, '2018-04-18', '', '', '', '', NULL, ''),
(63, '2018-04-18', '11700025', 'sdfsd', 'sdfsdf', 'sdfsd', NULL, ''),
(64, '2018-04-18', '11700025', '', '', '', NULL, ''),
(65, '2018-04-21', '11700025', 'ert', '', '', NULL, ''),
(66, '2018-04-30', '11700025', 'Lemas', 'Istirahat saja', 'Di UKP', NULL, ''),
(67, '2018-04-30', '11700026', 'dgdfg', 'dsfsdg', 'sdfds', NULL, ''),
(68, '2018-05-01', '11700039', 'asdasd', 'sdfdsfs', 'sdfsdf', NULL, ''),
(69, '2018-05-01', '11700039', 'sakit 2 kali', '2x3 obat', '', NULL, ''),
(70, '2018-05-06', '11700091', 'Lemas', 'Istirahat saja', 'tidak ada catatan', NULL, ''),
(71, '2018-05-06', '11700093', 'Pusing Pusing', 'Paramex', 'Berobat Ke Rumah Sakit selama 1 Hari', NULL, ''),
(72, '2018-05-06', '11700070', 'Lemas', 'Istirahat saja', 'ASDFASD', NULL, ''),
(73, '2018-05-06', '11700091', 'Pusing Pusing', 'Paramex', '-', NULL, ''),
(74, '2018-05-06', '11700090', 'Lemas', 'Istirahat saja', 'tidak ada catatan', NULL, ''),
(75, '2018-05-06', '11700091', 'Lemas', 'qqqqq', 'asdf', NULL, ''),
(76, '2018-05-06', '11700093', 'Lemas', 'www', 'alkdsfalksjdf', NULL, ''),
(77, '2018-05-06', '11700090', 'www', 'qqq', 'jajan', NULL, ''),
(78, '2018-05-06', '11700083', 'Lemas', 'qqqqq', 'ASDF', NULL, ''),
(79, '2018-05-06', '11700070', 'www', 'qqq', 'Di UKP', NULL, ''),
(80, '2018-05-06', '11700087', 'Pusing Pusing', 'www', 'tidak ada catatan', NULL, ''),
(81, '2018-05-06', '11700091', 'Lemas', 'qqqqq', 'tidak ada catatan', NULL, ''),
(82, '2018-05-17', '11700091', 'Sakit Kepala', 'Paramex', 'Istirahat 1 hari', NULL, ''),
(84, '2018-05-18', '11700093', 'dfds', 'sdfdsf', '', NULL, ''),
(86, '2018-05-19', '11700094', 'Sakit Gigi', 'Parasetamol', 'tidak ada', NULL, ''),
(87, '2018-05-22', '11700094', 'sas', 'sas', 'sa', NULL, ''),
(88, '2018-05-22', '11700070', 'd', 'dd', 'dd', NULL, ''),
(89, '2018-05-02', '11700070', 'Sakit Perut', 'Herbal dan Ramuan Tradisional', 'Di minta istirahat di asrama selama 10 jam', NULL, '');

-- --------------------------------------------------------

--
-- Table structure for table `mahrom`
--

CREATE TABLE `mahrom` (
  `nomor` varchar(10) DEFAULT NULL,
  `nis` varchar(50) DEFAULT NULL,
  `nama_mahrom` varchar(200) DEFAULT NULL,
  `status` varchar(50) DEFAULT NULL,
  `alamat` varchar(200) DEFAULT NULL,
  `telephon` varchar(50) DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `marhalah`
--

CREATE TABLE `marhalah` (
  `namamarhalah` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `marhalah`
--

INSERT INTO `marhalah` (`namamarhalah`) VALUES
('SD'),
('SLTA'),
('SLTP'),
('TK-PAUD');

-- --------------------------------------------------------

--
-- Table structure for table `matapelajaran`
--

CREATE TABLE `matapelajaran` (
  `kodemapel` varchar(10) NOT NULL,
  `namamapel` varchar(50) DEFAULT NULL,
  `pengguna` varchar(200) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Dumping data for table `matapelajaran`
--

INSERT INTO `matapelajaran` (`kodemapel`, `namamapel`, `pengguna`) VALUES
('TAU', 'TAUHID', 'sadmin'),
('FIB', 'FIB', 'sadmin'),
('FIM', 'FIM', 'sadmin'),
('HDS', 'HADIS', 'sadmin'),
('BID', 'BAHASA INDONESIA', ''),
('MTK', 'MATEMATIKA', ''),
('SKI', 'sejarah kebudayaan islam', '');

-- --------------------------------------------------------

--
-- Table structure for table `monitoringspp`
--

CREATE TABLE `monitoringspp` (
  `nis` varchar(50) NOT NULL,
  `setpoin` int(11) DEFAULT NULL,
  `kesanggupan` int(11) DEFAULT NULL,
  `juli` int(11) DEFAULT NULL,
  `agustus` int(11) DEFAULT NULL,
  `september` int(11) DEFAULT NULL,
  `oktober` int(11) DEFAULT NULL,
  `november` int(11) DEFAULT NULL,
  `desember` int(11) DEFAULT NULL,
  `januari` int(11) DEFAULT NULL,
  `februari` int(11) DEFAULT NULL,
  `maret` int(11) DEFAULT NULL,
  `april` int(11) DEFAULT NULL,
  `mei` int(11) DEFAULT NULL,
  `juni` int(11) DEFAULT NULL,
  `piutang` int(11) DEFAULT NULL,
  `juli2` int(11) DEFAULT NULL,
  `agustus2` int(11) DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `monitoringspp`
--

INSERT INTO `monitoringspp` (`nis`, `setpoin`, `kesanggupan`, `juli`, `agustus`, `september`, `oktober`, `november`, `desember`, `januari`, `februari`, `maret`, `april`, `mei`, `juni`, `piutang`, `juli2`, `agustus2`) VALUES
('11700070', 0, 0, 0, 0, 0, 0, 0, 0, 1000000, 1000000, 0, 0, 0, 0, NULL, NULL, NULL),
('11700109', 200000, 200000, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL),
('11700091', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, NULL, NULL),
('11700093', 0, 0, 0, 0, 0, 0, 0, 0, 1000000, 1000000, 0, 0, 0, 0, NULL, NULL, NULL),
('11700094', 1000000, 1000000, 0, 0, 0, 0, 0, 0, 1000000, 1000000, 0, 0, 0, 0, NULL, NULL, NULL),
('11700108', 200000, 200000, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `nilai`
--

CREATE TABLE `nilai` (
  `noid` double DEFAULT '0',
  `nis` varchar(50) DEFAULT NULL,
  `p1` int(11) DEFAULT '0',
  `p2` int(11) DEFAULT '0',
  `p3` int(11) DEFAULT '0',
  `p4` int(11) DEFAULT '0',
  `rp` int(11) DEFAULT '0',
  `u1` int(11) DEFAULT '0',
  `u2` int(11) DEFAULT '0',
  `u3` int(11) DEFAULT '0',
  `ru` int(11) DEFAULT '0',
  `nk` int(11) DEFAULT '0',
  `nh` int(11) DEFAULT '0',
  `rpu` int(11) DEFAULT '0',
  `m1` int(11) DEFAULT '0',
  `mh` int(11) DEFAULT '0',
  `rm` int(11) DEFAULT '0',
  `s1` int(11) DEFAULT '0',
  `rs` int(11) DEFAULT '0',
  `rt` int(11) DEFAULT '0',
  `her` int(11) DEFAULT '0'
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `nilai2`
--

CREATE TABLE `nilai2` (
  `id` int(32) NOT NULL,
  `nis` int(32) NOT NULL,
  `mapel` varchar(64) NOT NULL,
  `nilai` int(32) NOT NULL,
  `settingmapel_id` int(32) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `nilai2`
--

INSERT INTO `nilai2` (`id`, `nis`, `mapel`, `nilai`, `settingmapel_id`) VALUES
(136, 11700087, '', 75, 41),
(135, 11700091, '', 90, 41),
(134, 11700090, '', 80, 41),
(133, 11700089, '', 100, 41),
(132, 11700087, '', 85, 42),
(131, 11700091, '', 78, 42),
(130, 11700090, '', 87, 42),
(129, 11700089, '', 89, 42),
(128, 11700087, '', 80, 40),
(127, 11700091, '', 98, 40),
(126, 11700090, '', 75, 40),
(125, 11700089, '', 80, 40);

-- --------------------------------------------------------

--
-- Table structure for table `pegawai`
--

CREATE TABLE `pegawai` (
  `nik` int(11) NOT NULL,
  `nama` varchar(100) DEFAULT NULL,
  `namapanggilan` varchar(150) DEFAULT NULL,
  `gender` varchar(50) DEFAULT NULL,
  `kotalahir` varchar(50) DEFAULT NULL,
  `tanggallahir` date DEFAULT NULL,
  `alamat` varchar(200) DEFAULT NULL,
  `kota` varchar(100) DEFAULT NULL,
  `kodepos` varchar(20) DEFAULT NULL,
  `alamatktp` varchar(200) NOT NULL,
  `kotaktp` varchar(100) NOT NULL,
  `kodeposktp` varchar(20) NOT NULL,
  `nohp1` varchar(50) NOT NULL,
  `nohp2` varchar(50) NOT NULL,
  `noktp` varchar(50) NOT NULL,
  `statusnikah` varchar(50) NOT NULL,
  `nobpjs` varchar(50) NOT NULL,
  `npwp` varchar(50) NOT NULL,
  `golongandarah` varchar(20) NOT NULL,
  `mulaibekerjayayasan` date NOT NULL,
  `namaayah` varchar(50) NOT NULL,
  `namaibu` varchar(50) NOT NULL,
  `alamatorangtua` varchar(200) NOT NULL,
  `kotaorangtua` varchar(50) NOT NULL,
  `kodeposorangtua` varchar(50) NOT NULL,
  `hp1orangtua` varchar(50) NOT NULL,
  `hp2orangtua` varchar(50) NOT NULL,
  `pekerjaanayah` varchar(50) NOT NULL,
  `pekerjaanibu` varchar(50) NOT NULL,
  `anakke` varchar(20) NOT NULL,
  `bersaudara` varchar(20) NOT NULL,
  `daruratdihubungi` varchar(50) NOT NULL,
  `daruratperson` varchar(50) NOT NULL,
  `alamatdarurat` varchar(200) NOT NULL,
  `kotadarurat` varchar(50) NOT NULL,
  `kodeposdarurat` varchar(50) NOT NULL,
  `hp1darurat` varchar(50) NOT NULL,
  `hp2darurat` varchar(50) NOT NULL,
  `masuksd` varchar(10) NOT NULL,
  `keluarsd` varchar(10) NOT NULL,
  `lokasisd` varchar(50) NOT NULL,
  `studisd` varchar(50) NOT NULL,
  `masuksmp` varchar(10) NOT NULL,
  `keluarsmp` varchar(10) NOT NULL,
  `lokasismp` varchar(50) NOT NULL,
  `studismp` varchar(50) NOT NULL,
  `masuksma` varchar(10) NOT NULL,
  `keluarsma` varchar(10) NOT NULL,
  `lokasisma` varchar(50) NOT NULL,
  `studisma` varchar(50) NOT NULL,
  `s1masuk` varchar(10) NOT NULL,
  `s1keluar` varchar(10) NOT NULL,
  `lokasis1` varchar(50) NOT NULL,
  `studis1` varchar(50) NOT NULL,
  `s2masuk` varchar(10) NOT NULL,
  `s2keluar` varchar(10) NOT NULL,
  `lokasis2` varchar(50) NOT NULL,
  `studis2` varchar(50) NOT NULL,
  `s3masuk` varchar(10) NOT NULL,
  `s3keluar` varchar(10) NOT NULL,
  `lokasis3` varchar(50) NOT NULL,
  `studis3` varchar(50) NOT NULL,
  `keluar` tinyint(1) DEFAULT NULL,
  `jabatan` varchar(100) NOT NULL,
  `pendidikanterakhir` varchar(50) NOT NULL,
  `kelurahan` varchar(100) NOT NULL,
  `kecamatan` varchar(100) NOT NULL,
  `provinsi` varchar(100) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Dumping data for table `pegawai`
--

INSERT INTO `pegawai` (`nik`, `nama`, `namapanggilan`, `gender`, `kotalahir`, `tanggallahir`, `alamat`, `kota`, `kodepos`, `alamatktp`, `kotaktp`, `kodeposktp`, `nohp1`, `nohp2`, `noktp`, `statusnikah`, `nobpjs`, `npwp`, `golongandarah`, `mulaibekerjayayasan`, `namaayah`, `namaibu`, `alamatorangtua`, `kotaorangtua`, `kodeposorangtua`, `hp1orangtua`, `hp2orangtua`, `pekerjaanayah`, `pekerjaanibu`, `anakke`, `bersaudara`, `daruratdihubungi`, `daruratperson`, `alamatdarurat`, `kotadarurat`, `kodeposdarurat`, `hp1darurat`, `hp2darurat`, `masuksd`, `keluarsd`, `lokasisd`, `studisd`, `masuksmp`, `keluarsmp`, `lokasismp`, `studismp`, `masuksma`, `keluarsma`, `lokasisma`, `studisma`, `s1masuk`, `s1keluar`, `lokasis1`, `studis1`, `s2masuk`, `s2keluar`, `lokasis2`, `studis2`, `s3masuk`, `s3keluar`, `lokasis3`, `studis3`, `keluar`, `jabatan`, `pendidikanterakhir`, `kelurahan`, `kecamatan`, `provinsi`) VALUES
(10014, 'Handoko Tri', NULL, NULL, 'sdfsdf', '2018-04-03', 'sdfsdf', 'sdfsdf', NULL, '', '', '', '13214', '', '', 'Bujang', '', '', 'A', '0000-00-00', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 0, 'sdfsdf', 'SD', 'sdfsdf', 'sdfsdf', 'dfdg'),
(10011, 'Abdurrohim', NULL, 'Pria', 'Boyolali', '2018-04-30', 'jl. wonosari km.10', 'bantul', NULL, '', '', '', '081313213', '', '', 'Bujang', '', '', 'A', '0000-00-00', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 0, 'Guru', 'SD', 'karanggayam', 'piyungan', 'DIY'),
(10012, 'Hadi M', NULL, 'Pria', 'dsfgsdfgfd', '2018-04-04', 'dsfdsfsdgs', 'jhjhggj', NULL, '', '', '', '43534', '', '', 'Bujang', '', '', 'A', '0000-00-00', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 0, 'asdas', 'SD', '', '', ''),
(10013, 'AHMAD', NULL, 'Pria', 'sdfdsf', '2018-04-04', 'vjfgfh', 'nvhvhjbjh', NULL, '', '', '', '2342', '', '', 'Bujang', '', '', 'A', '0000-00-00', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 0, 'sdfsdf', 'SD', '', '', ''),
(10015, 'Hamdan Muhammad Rahadi', NULL, NULL, 'Pekalongan', '1981-05-16', 'Jl. Matahari Dalam', 'Palung', NULL, '', '', '', '0815465465', '', '', 'Menikah', '', '', 'AB', '0000-00-00', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 0, 'Guru', 'SLTP', 'Dalaman', 'Rahama', 'DIY');

-- --------------------------------------------------------

--
-- Table structure for table `pelanggaran`
--

CREATE TABLE `pelanggaran` (
  `nourut` double NOT NULL,
  `tanggal` date DEFAULT NULL,
  `nis` varchar(15) DEFAULT NULL,
  `namapelanggaran` varchar(200) DEFAULT NULL,
  `tindakan` varchar(200) DEFAULT NULL,
  `poin` double DEFAULT '0',
  `pengguna` varchar(200) NOT NULL,
  `catatan` varchar(250) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Dumping data for table `pelanggaran`
--

INSERT INTO `pelanggaran` (`nourut`, `tanggal`, `nis`, `namapelanggaran`, `tindakan`, `poin`, `pengguna`, `catatan`) VALUES
(1, '2018-02-09', '10244021003', 'mengambil', 'tindakan', 100, '', 'akan di pulangkan'),
(5, '2018-02-12', '10233022223', 'ASDF', 'SDF', 7, '', 'ASDF'),
(4, '2018-02-09', '10244021001', 'tidak ada', 'tidak ada', 9, '', 'ljhkjh'),
(6, '2018-02-12', '10322010020', 'AADFASDFAS', 'ASFSDF', 4, '', 'SDFSDF'),
(7, '2018-02-12', '10322010024', 'ASDF', 'ASDF', 35, '', 'ASDF'),
(8, '2018-03-03', '11700024', 'AADFASDFAS', 'ASDF', 10, '', 'ASDF'),
(9, '2018-04-01', '11700029', 'Menyimpan HP', 'Di Botak', 20, '', 'tidak ada catatan'),
(10, '2018-04-21', '', '', '', 1, '', ''),
(11, '2018-04-30', '11700024', 'Menyimpan HP', 'Di Botak', 10, '', 'tidak ada catatan'),
(12, '2018-05-01', '11700039', 'sdfsdf- ', 'sdfsd 1', 1, '', 'sdfdsfsdf'),
(13, '2018-05-01', '11700039', 'makan 10 kali', '2 kali 2', 1, '', ''),
(14, '2018-05-01', '11700039', 'makan 10 kali', '1 kali', 1, '', 'asdasd'),
(15, '2018-05-01', '11700073', 'wefs', 'sdfsdf', 1, '', ''),
(27, '2018-05-20', '11700108', 'bolos', 'poin', 20, '', ''),
(17, '2018-05-01', '11700073', 'dsfgd', 'dfgdf', 1, '', ''),
(25, '2018-05-20', '11700093', 'Bawa HP', 'poin 30', 15, '', ''),
(26, '2018-05-20', '11700070', 'Bawa laptop', 'poin ', 31, '', ''),
(28, '2018-05-20', '11700108', 'bolos', 'poin', 20, '', ''),
(29, '2018-05-19', '11700093', 'bolos', 'poin', 25, '', ''),
(30, '2018-05-01', '11700108', 'Terlambat', 'Peringatan', 10, '', 'tidak ada'),
(31, '2018-05-01', '11700094', 'Terlambat', 'nasihat', 10, '', ''),
(32, '2018-05-22', '11700093', 'Kabur Sewa motor dan pergi ke kota tanpa ijin pengurus', 'Di botak dan Di beri poin serta peringatan terakhir', 50, '', 'Diminta orang tuanya untuk hadir dan menandatangani surat peringatan terakhir');

-- --------------------------------------------------------

--
-- Table structure for table `prestasi`
--

CREATE TABLE `prestasi` (
  `nourut` double NOT NULL,
  `tanggal` date NOT NULL,
  `nis` varchar(100) NOT NULL,
  `prestasi` varchar(200) NOT NULL,
  `catatan` varchar(220) NOT NULL,
  `pengguna` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `prestasi`
--

INSERT INTO `prestasi` (`nourut`, `tanggal`, `nis`, `prestasi`, `catatan`, `pengguna`) VALUES
(6, '2017-05-21', '11133011029', 'Juara lomba lari', 'tidak ada catatan', 'sadmin'),
(14, '2017-05-21', '10922010002', 'Juara lomba lari', 'tidak ada catatan', 'sadmin'),
(15, '2017-05-21', '10922010002', 'Juara lomba lari', 'tidak ada catatan', 'sadmin'),
(16, '2017-05-21', '10922010002', 'Juara lomba lari', 'tidak ada catatan', 'sadmin'),
(17, '2017-05-21', '10522020008', 'Juara lomba lari', 'tidak ada catatan', 'sadmin'),
(18, '2017-05-21', '10522020008', 'Juara lomba lari', 'tidak ada catatan', 'sadmin'),
(19, '2017-05-21', '10522020008', 'Juara lomba lari', 'tidak ada catatan', 'sadmin'),
(20, '2017-07-19', '1021001', 'Juara 1 tahfidz', 'tidak ada', 'sadmin'),
(21, '2017-07-18', '1021001', 'Juara 2 tahfidz', 'tidak ada', 'sadmin'),
(22, '2017-08-16', '10922010001', 'Juara 2 Qiro`ah Kutub ICBB', 'Dilaksanakan Oleh Ospic', 'sadmin'),
(23, '2018-02-09', '10322010016', 'Juara Lomba makan', 'Tidak ada catatan', ''),
(24, '2018-02-10', '10322010020', 'juara 1', 'tidak ada', ''),
(25, '2018-03-03', '11700025', 'aaaaa', 'asdfasdf', ''),
(27, '2018-03-03', '11700027', 'aaaaa', 'ASDF', ''),
(28, '2018-04-30', '11700025', '', '', ''),
(29, '2018-04-30', '', 'ghf', 'dfg', ''),
(30, '2018-05-01', '11700039', 'asdasda', '', ''),
(31, '2018-04-01', '11700073', 'sdfsf', '', ''),
(32, '2018-05-01', '11700077', 'hhh', 'hhh', ''),
(33, '2018-05-01', '11700039', 'asdass', 'asdasd', ''),
(34, '2018-05-01', '11700073', 'juara 3', 'abcd', ''),
(35, '2018-05-08', '11700094', '1', 'lorem ipsum dolor sit amet', ''),
(39, '2018-05-01', '11700094', 'Lomba Tahfiz Kecamatan', 'tidak ada', ''),
(40, '2018-05-04', '11700070', 'Juara Lomba MHQ', 'Di Usulkan untuk naik ke tingkat propinsi dan di sponsori oleh sekolah', '');

-- --------------------------------------------------------

--
-- Table structure for table `rekening`
--

CREATE TABLE `rekening` (
  `kodegolongan` varchar(3) DEFAULT NULL,
  `koderekening` varchar(6) NOT NULL,
  `namarekening` varchar(100) DEFAULT NULL,
  `saldoawal` double DEFAULT '0',
  `debet` double DEFAULT '0',
  `kredit` double DEFAULT '0',
  `normal` tinyint(1) DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Dumping data for table `rekening`
--

INSERT INTO `rekening` (`kodegolongan`, `koderekening`, `namarekening`, `saldoawal`, `debet`, `kredit`, `normal`) VALUES
('100', '100099', 'KAS', 0, 0, 0, 1),
('100', '100001', 'KAS KECIL UANG SAKU', 0, 0, 0, 1),
('100', '100002', 'UANG MUKA SEMENTARA', 0, 0, 0, 1),
('100', '100009', 'PIUTANG LAIN - LAIN', 0, 0, 0, 1),
('100', '100011', 'BIAYA DIBAYAR DIMUKA', 0, 0, 0, 1),
('100', '100012', 'SEWA GEDUNG DIBAYAR DIMUKA', 0, 0, 0, 1),
('200', '200001', 'BANK BNI', 0, 0, 0, 1),
('200', '200002', 'BANK BRI', 0, 0, 0, 1),
('200', '200003', 'BANK BRI SITIMULYO', 0, 0, 0, 1),
('300', '300000', 'TANAH', 0, 0, 0, 1),
('300', '300001', 'BANGUNAN', 0, 0, 0, 1),
('300', '300002', 'AKUMULASI PENYUSUTAN BANGUNAN', 0, 0, 0, 1),
('300', '300003', 'KENDARAAN', 0, 0, 0, 1),
('300', '300004', 'AKUMULASI PENYUSUTAN KENDARAAN', 0, 0, 0, 1),
('300', '300005', 'PERALATAN KANTOR', 0, 0, 0, 1),
('300', '300006', 'AKUMULASI PENYUSUTAN PERALATAN KANTOR', 0, 0, 0, 1),
('300', '300007', 'PERABOTAN KANTOR', 0, 0, 0, 1),
('300', '300008', 'AKUMULASI PERABOTAN KANTOR', 0, 0, 0, 1),
('300', '300009', 'PERALATAN GEDUNG', 0, 0, 0, 1),
('300', '300010', 'AKUMULASI PERALATAN GEDUNG', 0, 0, 0, 1),
('300', '300011', 'PERABOTAN GEDUNG', 0, 0, 0, 1),
('300', '300012', 'AKUMULASI PENYUSUTAN PERABOTAN GEDUNG', 0, 0, 0, 1),
('300', '300013', 'LVA-PERALATAN KANTOR', 0, 0, 0, 1),
('300', '300014', 'LVA-AKUMULASI PENYUSUTAN PERALATAN KANTOR', 0, 0, 0, 1),
('300', '300015', 'LVA-PERABOTAN KANTOR', 0, 0, 0, 1),
('300', '300016', 'LVA-AKUMULASI PENYUSUTAN PERABOTAN KANTOR', 0, 0, 0, 1),
('300', '300017', 'LVA-PERALATAN GEDUNG', 0, 0, 0, 1),
('300', '300018', 'LVA-AKUMULASI PENYUSUTAN PERALATAN GEDUNG', 0, 0, 0, 1),
('300', '300019', 'LVA-PERABOTAN GEDUNG', 0, 0, 0, 1),
('300', '300020', 'LVA-AKUMULASI PENYUSUTAN PERABOTAN GEDUNG', 0, 0, 0, 1),
('400', '400000', 'HUTANG USAHA', 0, 0, 0, 0),
('400', '400001', 'HUTANG YAYASAN', 0, 0, 0, 0),
('400', '400002', 'DEPOSIT UANG SAKU', 0, 0, 0, 0),
('400', '400003', 'DEPOSIT SPP', 0, 0, 0, 0),
('400', '400004', 'DEPOSIT UANG CUCI', 0, 0, 0, 0),
('400', '400005', 'DEPOSIT DANA BOS', 0, 0, 0, 0),
('400', '400006', 'HUTANG LAIN-LAIN', 0, 0, 0, 0),
('400', '400007', 'BIAYA LAIN LAIN YMH DIBAYAR', 0, 0, 0, 0),
('400', '400008', 'DEPOSIT BIMBEL', 0, 0, 0, 0),
('400', '400009', 'DEPOSIT BANK', 0, 0, 0, 0),
('500', '500998', 'AKUN PENYEIMBANG', 0, 0, 0, 0),
('599', '599999', 'SALDO LABA TAHUN LALU', 0, 0, 0, 0),
('600', '600000', 'PENDAPATAN SPP', 0, 0, 0, 0),
('600', '600001', 'PENDAPATAN UANG PANGKAL', 0, 0, 0, 0),
('600', '600002', 'PENDAPATAN DAFTAR ULANG', 0, 0, 0, 0),
('600', '600003', 'PENDAPATAN UANG KESEHATAN', 0, 0, 0, 0),
('600', '600004', 'PENDAPATAN UANG RAPOR', 0, 0, 0, 0),
('600', '600005', 'PENDAPATAN INFAQ', 0, 0, 0, 0),
('600', '600006', 'HIBAH', 0, 0, 0, 0),
('600', '600007', 'PENDAPATAN BANK-BAGI HASIL', 0, 0, 0, 0),
('600', '600008', 'PENDAPATAN BUNGA BANK', 0, 0, 0, 0),
('600', '600009', 'PENDAPATAN LAIN-LAIN', 0, 0, 0, 0),
('600', '600010', 'PENDAPATAN BOS', 0, 0, 0, 0),
('600', '600011', 'PENDAPATAN FORMULIR PENDAFTARAN SB', 0, 0, 0, 0),
('600', '600012', 'PENDAPATAN DARI KHIDMAT', 0, 0, 0, 0),
('700', '700000', 'HONORARIUM GURU DAN TENAGA PENDIDIK HONO', 0, 0, 0, 1),
('700', '700001', 'UJIAN SEMESTER', 0, 0, 0, 1),
('700', '700002', 'PENGAWAS / PENGISI RAPOR', 0, 0, 0, 1),
('700', '700003', 'PEMBUAT SOAL', 0, 0, 0, 1),
('700', '700004', 'PENCETAKAN DOKUMEN', 0, 0, 0, 1),
('700', '700005', 'UJIAN AKHIR SEKOLAH', 0, 0, 0, 1),
('700', '700006', 'ULANGAN UMUM HARIAN', 0, 0, 0, 1),
('700', '700007', 'PENGADAAN BAHAN TEORI / PRAKTIK', 0, 0, 0, 1),
('700', '700008', 'PENGEMBANGAN POTENSI SISWA', 0, 0, 0, 1),
('700', '700009', 'KEGIATAN OSIS', 0, 0, 0, 1),
('700', '700010', 'PENYELENGGARAAN LOMBA / HADIAH', 0, 0, 0, 1),
('700', '700011', 'BAHASA', 0, 0, 0, 1),
('700', '700012', 'TAHFIDZ', 0, 0, 0, 1),
('700', '700013', 'OLAH RAGA', 0, 0, 0, 1),
('700', '700014', 'KREATIVITAS / ORGANISASI SANTRI', 0, 0, 0, 1),
('700', '700015', 'BUKU PELAJARAN POKOK', 0, 0, 0, 1),
('700', '700016', 'BUKU PENUNJANG', 0, 0, 0, 1),
('700', '700017', 'BANTUAN TRANSPORT UNTUK SISWA MISKIN', 0, 0, 0, 1),
('700', '700018', 'BIAYA PERBAIKAN SARANA', 0, 0, 0, 1),
('700', '700019', 'BIAYA PERBAIKAN MCK, AIR, DLL', 0, 0, 0, 1),
('700', '700020', 'BIAYA PERBAIKAN PERALATAN GEDUNG', 0, 0, 0, 1),
('700', '700021', 'BIAYA BERAS', 0, 0, 0, 1),
('700', '700022', 'BIAYA LAUK PAUK', 0, 0, 0, 1),
('700', '700023', 'BIAYA BUAH', 0, 0, 0, 1),
('700', '700024', 'BIAYA BAHAN BAKAR DAPUR', 0, 0, 0, 1),
('700', '700025', 'BIAYA PENERIMAAN SANTRI BARU', 0, 0, 0, 1),
('700', '700026', 'BIAYA KESEHATAN SANTRI', 0, 0, 0, 1),
('800', '800000', 'BIAYA GAJI KARYAWAN', 0, 0, 0, 1),
('800', '800001', 'BIAYA ATK( BUKU TULIS. SPIDOL. TINTA. DLL)', 0, 0, 0, 1),
('800', '800002', 'FOTO COPY', 0, 0, 0, 1),
('800', '800003', 'BIAYA POS DAN PENGIRIMAN', 0, 0, 0, 1),
('800', '800004', 'LANGGANAN LISTRIK', 0, 0, 0, 1),
('800', '800005', 'LANGGANAN TELEPON', 0, 0, 0, 1),
('800', '800006', 'BIAYA PERBAIKAN LISTRIK', 0, 0, 0, 1),
('800', '800007', 'BIAYA KEBERSIHAN', 0, 0, 0, 1),
('800', '800008', 'BIAYA PERBAIKAN KENDARAAN', 0, 0, 0, 1),
('800', '800009', 'BIAYA PERBAIKAN PERALATAN KANTOR', 0, 0, 0, 1),
('800', '800010', 'BIAYA BBM DAN PARKIR(OPERASIONAL)', 0, 0, 0, 1),
('800', '800011', 'BIAYA MAKAN MINUM', 0, 0, 0, 1),
('800', '800012', 'BIAYA JAMUAN TAMU', 0, 0, 0, 1),
('800', '800013', 'BIAYA KEAMANAN/ SATPAM', 0, 0, 0, 1),
('800', '800014', 'BIAYA TRAINING', 0, 0, 0, 1),
('800', '800015', 'BIAYA SUMBANGAN', 0, 0, 0, 1),
('800', '800016', 'BIAYA MATERAI', 0, 0, 0, 1),
('800', '800017', 'BIAYA OPERASIONAL LAIN-LAIN', 0, 0, 0, 1),
('800', '800018', 'BIAYA AIR', 0, 0, 0, 1),
('800', '800019', 'BIAYA KEPERLUAN KANTOR', 0, 0, 0, 1),
('800', '800020', 'BIAYA IKLAN DAN PROMOSI', 0, 0, 0, 1),
('800', '800021', 'BIAYA SEWA TANAH', 0, 0, 0, 1),
('800', '800022', 'BIAYA SEWA GEDUNG', 0, 0, 0, 1),
('800', '800023', 'BIAYA SEWA LAIN LAIN', 0, 0, 0, 1),
('800', '800024', 'BIAYA ADMINISTRASI BANK', 0, 0, 0, 1),
('800', '800025', 'BIAYA RECRUITMENT', 0, 0, 0, 1),
('800', '800026', 'BIAYA PERJALANAN DINAS', 0, 0, 0, 1),
('800', '800027', 'BIAYA HONOR', 0, 0, 0, 1),
('600', '600100', 'PENDAPATAN ABCD', 1000000, 0, 0, 0),
('100', '100100', 'KAS ABCD', 1000000, 0, 0, 0),
('100', '100110', 'KAS BINBAZ', 0, 0, 0, 0);

-- --------------------------------------------------------

--
-- Table structure for table `sekolah`
--

CREATE TABLE `sekolah` (
  `nomorindukpegawai` varchar(50) NOT NULL,
  `namasekolah` varchar(200) NOT NULL,
  `kepalasekolah` varchar(100) NOT NULL,
  `notelpon` varchar(50) NOT NULL,
  `nohp` varchar(50) NOT NULL,
  `email` varchar(100) NOT NULL,
  `alamat` varchar(200) NOT NULL,
  `kecamatan` varchar(70) NOT NULL,
  `kabupaten` varchar(70) NOT NULL,
  `provinsi` varchar(70) NOT NULL,
  `moto` varchar(100) NOT NULL,
  `visimisi` text NOT NULL,
  `marhalah1` varchar(100) NOT NULL,
  `marhalah2` varchar(100) NOT NULL,
  `marhalah3` varchar(100) NOT NULL,
  `marhalah4` varchar(100) NOT NULL,
  `marhalah5` varchar(100) NOT NULL,
  `marhalah6` varchar(100) NOT NULL,
  `logobesar` varchar(240) NOT NULL,
  `logokecil` varchar(240) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `sekolah`
--

INSERT INTO `sekolah` (`nomorindukpegawai`, `namasekolah`, `kepalasekolah`, `notelpon`, `nohp`, `email`, `alamat`, `kecamatan`, `kabupaten`, `provinsi`, `moto`, `visimisi`, `marhalah1`, `marhalah2`, `marhalah3`, `marhalah4`, `marhalah5`, `marhalah6`, `logobesar`, `logokecil`) VALUES
('1982828 28289 1 901', 'Qodr', 'Ahmad Yahdi', '0818029999999', '0818088888888', 'yahdi@gmail.com', 'Jl. Ahmad Dahlan No 3', 'Singosari', 'Bantul', 'DIY', 'Mendidik Generasi Robbani', 'Mencetak Generasi Muslim Yang ', 'Madrasah Aliyah', 'Salafiyah Wustho', 'Salafiyah Ula', 'TK Bunayya', 'PAUD ICBB', '', '', 'loog.jpeg');

-- --------------------------------------------------------

--
-- Table structure for table `setingmapel`
--

CREATE TABLE `setingmapel` (
  `noid` int(11) NOT NULL,
  `kodemapel` varchar(50) DEFAULT NULL,
  `nik` double DEFAULT '0',
  `kelas` varchar(50) DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Dumping data for table `setingmapel`
--

INSERT INTO `setingmapel` (`noid`, `kodemapel`, `nik`, `kelas`) VALUES
(42, 'MTK', 10014, 'I.B'),
(41, 'SKI', 10014, 'I.B'),
(40, 'TAU', 10011, 'I.B');

-- --------------------------------------------------------

--
-- Table structure for table `siswa`
--

CREATE TABLE `siswa` (
  `nis` double NOT NULL,
  `namasiswa` varchar(50) DEFAULT NULL,
  `kotalahir` varchar(50) DEFAULT NULL,
  `tanggallahir` date DEFAULT NULL,
  `jeniskelamin` varchar(20) DEFAULT NULL,
  `anakke` varchar(5) DEFAULT NULL,
  `bersaudara` varchar(5) DEFAULT NULL,
  `golongandarah` varchar(2) DEFAULT NULL,
  `marhalah` varchar(50) DEFAULT NULL,
  `kelas` varchar(10) DEFAULT NULL,
  `spp` double DEFAULT NULL,
  `nokk` varchar(50) DEFAULT NULL,
  `email` varchar(100) DEFAULT NULL,
  `ttlayah` varchar(200) DEFAULT NULL,
  `noktpayah` varchar(50) DEFAULT NULL,
  `pendidikanayah` varchar(200) DEFAULT NULL,
  `gajiayah` double DEFAULT NULL,
  `namaayah` varchar(50) DEFAULT NULL,
  `pekerjaanayah` varchar(50) DEFAULT NULL,
  `ttlibu` varchar(200) DEFAULT NULL,
  `noktpibu` varchar(100) DEFAULT NULL,
  `pendidikanibu` varchar(200) DEFAULT NULL,
  `gajiibu` double DEFAULT NULL,
  `namaibu` varchar(50) DEFAULT NULL,
  `pekerjaanibu` varchar(50) DEFAULT NULL,
  `alamat` varchar(200) DEFAULT NULL,
  `kelurahan` varchar(100) DEFAULT NULL,
  `kecamatan` varchar(100) DEFAULT NULL,
  `alamatkota` varchar(150) DEFAULT NULL,
  `provinsi` varchar(50) DEFAULT NULL,
  `telephon` varchar(50) DEFAULT NULL,
  `telephonrumah` varchar(50) DEFAULT NULL,
  `asalsekolah` varchar(150) DEFAULT NULL,
  `alamatsekolah` varchar(150) DEFAULT NULL,
  `tanggalmasuk` datetime DEFAULT NULL,
  `noinduk` varchar(200) DEFAULT NULL,
  `ijasah` varchar(60) DEFAULT NULL,
  `akte` varchar(50) DEFAULT NULL,
  `skhun` varchar(50) DEFAULT NULL,
  `nisn` varchar(50) DEFAULT NULL,
  `uangpangkal` double DEFAULT '0',
  `daftarulang` double DEFAULT '0',
  `lokasitest` varchar(100) DEFAULT NULL,
  `edit` varchar(10) DEFAULT NULL,
  `lulus` tinyint(4) DEFAULT NULL,
  `keterangan` varchar(200) DEFAULT NULL,
  `foto` varchar(250) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Dumping data for table `siswa`
--

INSERT INTO `siswa` (`nis`, `namasiswa`, `kotalahir`, `tanggallahir`, `jeniskelamin`, `anakke`, `bersaudara`, `golongandarah`, `marhalah`, `kelas`, `spp`, `nokk`, `email`, `ttlayah`, `noktpayah`, `pendidikanayah`, `gajiayah`, `namaayah`, `pekerjaanayah`, `ttlibu`, `noktpibu`, `pendidikanibu`, `gajiibu`, `namaibu`, `pekerjaanibu`, `alamat`, `kelurahan`, `kecamatan`, `alamatkota`, `provinsi`, `telephon`, `telephonrumah`, `asalsekolah`, `alamatsekolah`, `tanggalmasuk`, `noinduk`, `ijasah`, `akte`, `skhun`, `nisn`, `uangpangkal`, `daftarulang`, `lokasitest`, `edit`, `lulus`, `keterangan`, `foto`) VALUES
(11700093, 'ganbaro minna', 'jepun', '2018-05-03', 'Pria', '1', NULL, 'O', NULL, 'IX.D', 100000, '', '', '', '', '', 0, '', '', '', '', '', 0, '', '', '', '', '', '', '', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1500000, 1000000, NULL, NULL, 0, NULL, '4980c06ff3f000c38c511ec993d69933.png'),
(11700070, 'Handoko Tri', 'sdfsdf', '2018-04-30', 'Pria', '1', NULL, 'A', NULL, 'IX.A', 50000, '123123123', '', '', '', '', 0, 'dsfdsfs', '', '', '', '', 0, 'ksdjfhkds', '', '', '', '', '', '', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 15000000, 2000000, NULL, NULL, 0, NULL, 'fc99520837008082e2ae70e50cb42af1.png'),
(11700109, 'Hikmah Rasyid', 'Kotabumi', '2000-05-10', 'Pria', '3', NULL, 'B', NULL, 'IX.H', 200000, '1111', 'yadi@gmail.com', 'Kota Bumi, 19 8 1977', '22222', 'sma', 0, 'Panjaitan', 'Swasta', '', '', '', 0, 'sdfsdfs', '', '', '', '', '', '', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, 3000000, NULL, NULL, 0, NULL, '32fb908771b34ea0317fe15cb9f7f4e3.png'),
(11700094, 'Muhammad Hakim Almadani', 'bukittinggi', '2000-04-22', 'Wanita', '1', NULL, 'AB', 'MA', 'IV.A', 1000000, '145558329329243', 'admin@admin.lol', 'bangkinang', '234287323492333333', 'S3', 100000, 'Abdullah', 'manager', 'bukittinggi', '145555523422322', 'S4', 40000000, 'aisyah', 'ibu rumah tangga', 'Rt 005 Rw 006 jl arbes', 'pangkalan kerinci timur', 'pelalawan', 'pangkalan kerinci', 'riau', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 5000000, 10000, NULL, NULL, 0, NULL, '6deefea5695d15a971af41b15be54e8f.png'),
(11700108, 'Abdul Aziz', 'Dumai', '2006-03-02', 'Pria', '1', NULL, 'B', NULL, 'I.B', 200000, '12321', 'bangkurs90@gmail.com', 'Jakarta 19 02 1980', '12341', 'asdas', 0, 'HERU ANWAR', 'Karyawan', NULL, NULL, NULL, NULL, NULL, NULL, 'Jl. KH. Ahmad Dahlan', 'Nunukan', 'ABCD', 'Jogja', 'DIY', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, 1500000, NULL, NULL, 0, NULL, 'dcf7fbcb30b85abf344acd4c9222dcf9.png');

--
-- Triggers `siswa`
--
DELIMITER $$
CREATE TRIGGER `siswamonitoringspp` AFTER INSERT ON `siswa` FOR EACH ROW BEGIN

      INSERT INTO monitoringspp (nis,setpoin,kesanggupan) 
      VALUES (new.nis,new.spp,new.spp);   

END
$$
DELIMITER ;

-- --------------------------------------------------------

--
-- Table structure for table `siswaalumni`
--

CREATE TABLE `siswaalumni` (
  `nis` varchar(50) NOT NULL,
  `namasiswa` varchar(100) NOT NULL,
  `namatahunajaran` varchar(20) NOT NULL,
  `notelpon` varchar(50) NOT NULL,
  `alamatsekarang` varchar(150) NOT NULL,
  `email` varchar(50) NOT NULL,
  `kuliahkerja` varchar(50) NOT NULL,
  `instansi` varchar(150) NOT NULL,
  `catatan` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `siswakeluar`
--

CREATE TABLE `siswakeluar` (
  `nis` double NOT NULL,
  `tanggal` date NOT NULL,
  `keterangan` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `siswakeluar`
--

INSERT INTO `siswakeluar` (`nis`, `tanggal`, `keterangan`) VALUES
(1151588, '2017-09-07', 'tidak apa2'),
(11211019, '2017-05-02', 'Pindah Sementara'),
(11111011480, '2017-05-09', 'Pindah Sementara');

-- --------------------------------------------------------

--
-- Table structure for table `tahfidz`
--

CREATE TABLE `tahfidz` (
  `nourut` double NOT NULL,
  `tanggal` date DEFAULT NULL,
  `nis` varchar(50) DEFAULT NULL,
  `tambahan` double DEFAULT NULL,
  `murojaah` varchar(250) DEFAULT NULL,
  `totalhafalan` double DEFAULT NULL,
  `murojaahbaru` varchar(250) NOT NULL,
  `tambahanketerangan` varchar(250) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Dumping data for table `tahfidz`
--

INSERT INTO `tahfidz` (`nourut`, `tanggal`, `nis`, `tambahan`, `murojaah`, `totalhafalan`, `murojaahbaru`, `tambahanketerangan`) VALUES
(25, '2018-05-12', '11700091', 2, '4 halaman', NULL, '4 halaman', 'an-naba'),
(15, '2018-05-01', '11700070', 1, 'hafalan', NULL, '', 'hafalan'),
(14, '2018-05-01', '11700039', 1, 'halaman', NULL, 'halaman', 'halman'),
(13, '2018-05-01', '11700039', 1, 'asdasda', NULL, '', 'asdasd'),
(17, '2018-05-01', '11700070', 1, 'halaman 2-3', NULL, '', 'halaman 2-3'),
(18, '2018-05-01', '11700039', 1, 'halaman 2-3', NULL, '', 'halaman 2-3'),
(19, '2018-05-01', '11700039', 1, '2 - 5 halaman', NULL, '2', '3 halaman'),
(20, '2018-05-01', '11700073', 1, '2 - 5 halaman', NULL, '', '2'),
(21, '2018-05-01', '11700039', 1, 'wefew', NULL, 'esdfwef', 'asdas'),
(22, '2018-05-01', '11700039', 1, '2 halaman', NULL, '', 'halaman 2-3'),
(27, '2018-05-19', '11700094', 1, 'dsd', NULL, 'dsd', 'ds'),
(26, '2018-05-19', '11700070', 5, 'yy', NULL, 'yy', 'yyy'),
(28, '2018-05-01', '11700108', 1, 'Juz 29', NULL, 'Albaqoroh 1-11', 'albaqoroh 12-20'),
(29, '2018-05-08', '11700108', 1, 'juz 28', NULL, 'albaqoroh 1-29', 'albaqoroh 21-30'),
(30, '2018-05-01', '11700070', 1, 'sdfsd', NULL, '', 'lknkdfngd'),
(31, '2018-05-03', '11700093', 1, 'dfgdfg', NULL, '', 'dfgdfg'),
(32, '2018-05-02', '11700093', 1, 'dfgd', NULL, '', 'dgfg'),
(33, '2018-05-03', '11700093', 1, 'dfgdf', NULL, '', 'dgdf'),
(34, '2018-05-03', '11700093', 1, 'lkk', NULL, '', 'jkn'),
(35, '2018-05-02', '11700093', 1, 'dfgdf', NULL, '', 'dfgdfg'),
(36, '2018-05-01', '11700070', 1, 'lkj', NULL, '', 'hkj'),
(37, '2018-05-02', '11700070', 1, 'hjkhk', NULL, '', 'hjgjj'),
(38, '2018-05-23', '11700070', 1, 'SQS', NULL, 'SQ', 'AAAAAQ');

-- --------------------------------------------------------

--
-- Table structure for table `tahunajaran`
--

CREATE TABLE `tahunajaran` (
  `namatahunajaran` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tahunajaran`
--

INSERT INTO `tahunajaran` (`namatahunajaran`) VALUES
('2014-2015'),
('2015-2016'),
('2016-2017'),
('2017-2018'),
('2018-2019');

-- --------------------------------------------------------

--
-- Table structure for table `test`
--

CREATE TABLE `test` (
  `userid` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL,
  `dept` varchar(255) NOT NULL,
  `kode_nota` varchar(255) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `test`
--

INSERT INTO `test` (`userid`, `password`, `dept`, `kode_nota`) VALUES
('aaa', 'aaa', 'aaa', 'aaa'),
('qqq', 'qqq', 'qqq', 'qqq'),
('sadfsf', 'sdfsdf', 'sdfsd', 'sdfsd'),
('asd', 'sdfsdf', 'sdfsd', 'sdfsd'),
('asdas', '', '', ''),
('a', 'a', 'a', 'a'),
('t', 'a', 'a', 'a'),
('q', 'q', 'q', 'q'),
('2', 'a', 'a', 'a'),
('c', 'a', 'a', 'a'),
('asdasd', 'as', 'as', 'as'),
('12', '', '', ''),
('tttt', '', '', ''),
('asasd', '', '', ''),
('sadfasd', '', '', ''),
('swedf', 'AA', 'AAAA', 'AAA'),
('asdasdas', 'a', 'a', 'a'),
('asdasdf SDF', 'a', 'a', 'a'),
('fdgdfgd', 'a', 'asfda', 'sdfsdf');

-- --------------------------------------------------------

--
-- Table structure for table `uangsakukeluar`
--

CREATE TABLE `uangsakukeluar` (
  `nonota` double NOT NULL,
  `nis` varchar(12) DEFAULT NULL,
  `uangkeluar` double DEFAULT '0',
  `tanggal` date DEFAULT NULL,
  `pengguna` varchar(20) DEFAULT NULL,
  `catatan` varchar(120) DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Triggers `uangsakukeluar`
--
DELIMITER $$
CREATE TRIGGER `jurnaluangsakukeluar` AFTER INSERT ON `uangsakukeluar` FOR EACH ROW BEGIN

INSERT INTO jurnal (tanggal,nonota,koderekening,debet,keterangan,pengguna) 
VALUES(NEW.tanggal,NEW.nonota,'400002',NEW.uangkeluar,NEW.catatan,NEW.pengguna);
INSERT INTO jurnal (tanggal,nonota,koderekening,kredit,keterangan,pengguna) 
VALUES(NEW.tanggal,NEW.nonota,'100099',NEW.uangkeluar,NEW.catatan,NEW.pengguna);
END
$$
DELIMITER ;

-- --------------------------------------------------------

--
-- Table structure for table `user`
--

CREATE TABLE `user` (
  `id` int(11) NOT NULL,
  `name` char(30) NOT NULL,
  `username` char(30) NOT NULL,
  `password` mediumtext NOT NULL,
  `group_id` int(11) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `user`
--

INSERT INTO `user` (`id`, `name`, `username`, `password`, `group_id`) VALUES
(1, 'Administrator', 'admin', 'd033e22ae348aeb5660fc2140aec35850c4da997', 1),
(2, 'Operator', 'operator', 'fe96dd39756ac41b74283a9292652d366d73931f', 2),
(3, 'Keuangan', 'keuangan', '1f931595786f2f178358d0af5fe4d75eaee46819', 3),
(4, 'Service', 'service', '4cf5bc59bee9e1c44c6254b5f84e7f066bd8e5fe', 4);

-- --------------------------------------------------------

--
-- Table structure for table `user2`
--

CREATE TABLE `user2` (
  `userid` varchar(20) NOT NULL,
  `password` varchar(50) NOT NULL,
  `dept` char(20) NOT NULL,
  `kodenota` varchar(2) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `user2`
--

INSERT INTO `user2` (`userid`, `password`, `dept`, `kodenota`) VALUES
('orangtua', 'orangtua', '', 'OT'),
('guru', 'guru', '', 'GR'),
('staf', 'staf', '', 'MN'),
('dokter', 'dokter', '', 'DR'),
('keuangan', 'keuangan', '', 'KU'),
('admin', 'admin', '', 'AD'),
('', '', '', 'AS'),
('ystef', '', '', 'Qd'),
('kakak', 'kaka', '', 'Qs'),
('NN', 'nn', '', 'Qp'),
('error', 'oo', '', 'QW');

-- --------------------------------------------------------

--
-- Table structure for table `userhalaman`
--

CREATE TABLE `userhalaman` (
  `noid` int(11) NOT NULL,
  `userid` varchar(50) NOT NULL,
  `halaman` varchar(50) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `userhalaman`
--

INSERT INTO `userhalaman` (`noid`, `userid`, `halaman`) VALUES
(39, 'keuangan', 'Nilai-Raport Admin'),
(38, 'keuangan', 'Keuangan Admin'),
(37, 'keuangan', 'Keuangan'),
(36, 'admin', 'Nilai-Raport Admin'),
(35, 'admin', 'Nilai-Raport'),
(34, 'admin', 'Tahfidz'),
(33, 'admin', 'Prestasi'),
(32, 'admin', 'Pelanggaran'),
(31, 'admin', 'Perizinan'),
(30, 'admin', 'Kesehatan'),
(29, 'admin', 'Keuangan Admin'),
(28, 'admin', 'Keuangan'),
(27, 'admin', 'Tata Usaha'),
(26, 'admin', 'Admin'),
(40, 'dokter', 'Kesehatan'),
(41, 'staf', 'Tata Usaha'),
(42, 'staf', 'Perizinan'),
(43, 'staf', 'Pelanggaran'),
(44, 'Guru', 'Tahfidz'),
(45, 'Guru', 'Nilai-Raport'),
(46, 'Guru', 'Nilai-Raport Admin'),
(47, 'orangtua', 'Keuangan'),
(48, 'orangtua', 'Kesehatan'),
(49, 'orangtua', 'Perizinan'),
(50, 'orangtua', 'Pelanggaran'),
(51, 'orangtua', 'Prestasi'),
(52, 'orangtua', 'Tahfidz'),
(53, 'orangtua', 'Nilai-Raport'),
(69, 'kakak', 'Perizinan'),
(68, 'kakak', 'Kesehatan'),
(67, 'kakak', 'Keuangan'),
(74, 'staf', 'Tahfidz');

-- --------------------------------------------------------

--
-- Table structure for table `userorangtua`
--

CREATE TABLE `userorangtua` (
  `nourut` int(11) NOT NULL,
  `userid` varchar(200) NOT NULL,
  `password` varchar(250) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` int(11) UNSIGNED NOT NULL,
  `ip_address` varchar(45) NOT NULL,
  `username` varchar(100) DEFAULT NULL,
  `password` varchar(255) NOT NULL,
  `salt` varchar(255) DEFAULT NULL,
  `email` varchar(254) NOT NULL,
  `activation_code` varchar(40) DEFAULT NULL,
  `forgotten_password_code` varchar(40) DEFAULT NULL,
  `forgotten_password_time` int(11) UNSIGNED DEFAULT NULL,
  `remember_code` varchar(40) DEFAULT NULL,
  `created_on` int(11) UNSIGNED NOT NULL,
  `last_login` int(11) UNSIGNED DEFAULT NULL,
  `active` tinyint(1) UNSIGNED DEFAULT NULL,
  `first_name` varchar(50) DEFAULT NULL,
  `last_name` varchar(50) DEFAULT NULL,
  `company` varchar(100) DEFAULT NULL,
  `phone` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `ip_address`, `username`, `password`, `salt`, `email`, `activation_code`, `forgotten_password_code`, `forgotten_password_time`, `remember_code`, `created_on`, `last_login`, `active`, `first_name`, `last_name`, `company`, `phone`) VALUES
(1, '127.0.0.1', 'administrator', '$2a$07$SeBknntpZror9uyftVopmu61qg0ms8Qv1yV6FG.kQOSM.9QhmTo36', '', 'admin@admin.com', '', NULL, NULL, NULL, 1268889823, 1524467653, 1, 'Admin', 'istrator', 'ADMIN', '0');

-- --------------------------------------------------------

--
-- Table structure for table `usersiswa`
--

CREATE TABLE `usersiswa` (
  `username` varchar(100) NOT NULL,
  `password` varchar(240) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `usersiswa`
--

INSERT INTO `usersiswa` (`username`, `password`) VALUES
('11700025', '11700025'),
('11700026', '11700026');

-- --------------------------------------------------------

--
-- Stand-in structure for view `vabsensisiswa`
-- (See below for the actual view)
--
CREATE TABLE `vabsensisiswa` (
`nourut` double
,`nis` varchar(50)
,`tanggal` date
,`tanggalakhir` date
,`sakit` int(11)
,`ijin` int(11)
,`alpa` int(11)
,`catatan` varchar(100)
,`pengguna` varchar(50)
,`namasiswa` varchar(50)
,`marhalah` varchar(50)
,`kelas` varchar(10)
);

-- --------------------------------------------------------

--
-- Stand-in structure for view `vdaftarnilaikosong`
-- (See below for the actual view)
--
CREATE TABLE `vdaftarnilaikosong` (
`noid` int(11)
,`kodemapel` varchar(50)
,`nik` double
,`kelas` varchar(50)
,`namasiswa` varchar(50)
,`nis` double
,`nama` varchar(100)
);

-- --------------------------------------------------------

--
-- Stand-in structure for view `vjurnal`
-- (See below for the actual view)
--
CREATE TABLE `vjurnal` (
`nourut` double
,`tanggal` date
,`nonota` varchar(50)
,`koderekening` double
,`debet` double
,`kredit` double
,`keterangan` varchar(250)
,`pengguna` varchar(100)
,`namarekening` varchar(100)
,`normal` tinyint(1)
);

-- --------------------------------------------------------

--
-- Stand-in structure for view `vkesehatan`
-- (See below for the actual view)
--
CREATE TABLE `vkesehatan` (
`nourut` double
,`tanggal` date
,`nis` varchar(15)
,`keluhan` varchar(200)
,`obat` varchar(200)
,`catatan` varchar(200)
,`keparahan` varchar(50)
,`pengguna` varchar(200)
,`namasiswa` varchar(50)
,`marhalah` varchar(50)
,`kelas` varchar(10)
);

-- --------------------------------------------------------

--
-- Stand-in structure for view `vmonitoringspp`
-- (See below for the actual view)
--
CREATE TABLE `vmonitoringspp` (
`nis` varchar(50)
,`setpoin` int(11)
,`kesanggupan` int(11)
,`juli` int(11)
,`agustus` int(11)
,`september` int(11)
,`oktober` int(11)
,`november` int(11)
,`desember` int(11)
,`januari` int(11)
,`februari` int(11)
,`maret` int(11)
,`april` int(11)
,`mei` int(11)
,`juni` int(11)
,`piutang` int(11)
,`juli2` int(11)
,`agustus2` int(11)
,`namasiswa` varchar(50)
,`marhalah` varchar(50)
,`kelas` varchar(10)
,`namaayah` varchar(50)
,`namaibu` varchar(50)
);

-- --------------------------------------------------------

--
-- Stand-in structure for view `vneracasaldo`
-- (See below for the actual view)
--
CREATE TABLE `vneracasaldo` (
`totdebet` double
,`totkredit` double
,`koderekening` double
,`namarekening` varchar(100)
);

-- --------------------------------------------------------

--
-- Stand-in structure for view `vnilai`
-- (See below for the actual view)
--
CREATE TABLE `vnilai` (
`id` int(32)
,`nis` int(32)
,`mapel` varchar(64)
,`nilai` int(32)
,`settingmapel_id` int(32)
,`namasiswa` varchar(50)
,`kelas` varchar(10)
,`namamapel` varchar(50)
,`nama` varchar(100)
,`kodemapel` varchar(50)
,`nik` double
);

-- --------------------------------------------------------

--
-- Stand-in structure for view `vnilairata`
-- (See below for the actual view)
--
CREATE TABLE `vnilairata` (
`nis` int(32)
,`namasiswa` varchar(50)
,`kelas` varchar(10)
,`totnilai` decimal(53,0)
,`totmapel` bigint(21)
,`ratanilai` decimal(57,4)
);

-- --------------------------------------------------------

--
-- Stand-in structure for view `vpelanggaran`
-- (See below for the actual view)
--
CREATE TABLE `vpelanggaran` (
`nourut` double
,`tanggal` date
,`nis` varchar(15)
,`namapelanggaran` varchar(200)
,`tindakan` varchar(200)
,`poin` double
,`pengguna` varchar(200)
,`namasiswa` varchar(50)
,`marhalah` varchar(50)
,`kelas` varchar(10)
);

-- --------------------------------------------------------

--
-- Stand-in structure for view `vpelanggaranrekap`
-- (See below for the actual view)
--
CREATE TABLE `vpelanggaranrekap` (
`totalpoin` double
,`namasiswa` varchar(50)
,`nis` varchar(15)
,`kelas` varchar(10)
);

-- --------------------------------------------------------

--
-- Stand-in structure for view `vpenerimaan`
-- (See below for the actual view)
--
CREATE TABLE `vpenerimaan` (
`nis` varchar(12)
,`tanggal` date
,`nonota` varchar(15)
,`transfer` varchar(50)
,`pengguna` varchar(20)
,`tanggaldokumen` date
,`total` double
,`namasiswa` varchar(50)
,`kelas` varchar(10)
,`namaayah` varchar(50)
,`telephon` varchar(50)
);

-- --------------------------------------------------------

--
-- Stand-in structure for view `vperizinan`
-- (See below for the actual view)
--
CREATE TABLE `vperizinan` (
`nourut` int(11)
,`nis` varchar(20)
,`tanggalizin` date
,`tanggalkembali` date
,`penjemput` varchar(200)
,`catatan` varchar(200)
,`namasiswa` varchar(50)
,`marhalah` varchar(50)
,`kelas` varchar(10)
);

-- --------------------------------------------------------

--
-- Stand-in structure for view `vprestasi`
-- (See below for the actual view)
--
CREATE TABLE `vprestasi` (
`nourut` double
,`tanggal` date
,`nis` varchar(100)
,`prestasi` varchar(200)
,`catatan` varchar(220)
,`pengguna` varchar(100)
,`namasiswa` varchar(50)
,`marhalah` varchar(50)
,`kelas` varchar(10)
);

-- --------------------------------------------------------

--
-- Stand-in structure for view `vselainspp`
-- (See below for the actual view)
--
CREATE TABLE `vselainspp` (
`nis` varchar(12)
,`tanggal` date
,`nonota` varchar(15)
,`transfer` varchar(50)
,`pengguna` varchar(20)
,`daftarulang` double
,`uangpangkal` double
,`infaq` double
,`uangsakumasuk` double
,`bimbel` double
,`keteranganinfaq` varchar(150)
,`tanggaldokumen` date
,`namasiswa` varchar(50)
,`kelas` varchar(10)
,`namaayah` varchar(50)
,`telephon` varchar(50)
);

-- --------------------------------------------------------

--
-- Stand-in structure for view `vsetingmapel`
-- (See below for the actual view)
--
CREATE TABLE `vsetingmapel` (
`noid` int(11)
,`kodemapel` varchar(50)
,`nik` double
,`kelas` varchar(50)
,`namamapel` varchar(50)
,`nama` varchar(100)
,`walikelas` varchar(100)
);

-- --------------------------------------------------------

--
-- Stand-in structure for view `vsiswakeluar`
-- (See below for the actual view)
--
CREATE TABLE `vsiswakeluar` (
`nis` double
,`tanggal` date
,`keterangan` varchar(255)
,`namasiswa` varchar(50)
,`marhalah` varchar(50)
,`kelas` varchar(10)
,`namaayah` varchar(50)
,`namaibu` varchar(50)
);

-- --------------------------------------------------------

--
-- Stand-in structure for view `vspp`
-- (See below for the actual view)
--
CREATE TABLE `vspp` (
`nis` varchar(12)
,`tanggal` date
,`nonota` varchar(15)
,`transfer` varchar(50)
,`pengguna` varchar(20)
,`januari` double
,`februari` double
,`maret` double
,`april` double
,`mei` double
,`juni` double
,`juli` double
,`agustus` double
,`september` double
,`oktober` double
,`november` double
,`desember` double
,`tanggaldokumen` date
,`namasiswa` varchar(50)
,`kelas` varchar(10)
,`namaayah` varchar(50)
,`telephon` varchar(50)
);

-- --------------------------------------------------------

--
-- Stand-in structure for view `vtagihan`
-- (See below for the actual view)
--
CREATE TABLE `vtagihan` (
`nis` varchar(12)
,`totaluangpangkal` double
,`uangpangkal` double
,`kuranguangpangkal` double
,`totaldaftarulang` double
,`daftarulang` double
,`totaldaftarualng` double
,`totalbimbel` double
,`januari` int(11)
,`februari` int(11)
,`maret` int(11)
,`april` int(11)
,`mei` int(11)
,`juni` int(11)
,`juli` int(11)
,`agustus` int(11)
,`september` int(11)
,`oktober` int(11)
,`november` int(11)
,`desember` int(11)
,`namasiswa` varchar(50)
,`kelas` varchar(10)
,`telephon` varchar(50)
,`namaayah` varchar(50)
);

-- --------------------------------------------------------

--
-- Stand-in structure for view `vtahfidz`
-- (See below for the actual view)
--
CREATE TABLE `vtahfidz` (
`nourut` double
,`tanggal` date
,`nis` varchar(50)
,`tambahan` double
,`murojaah` varchar(250)
,`totalhafalan` double
,`murojaahbaru` varchar(250)
,`tambahanketerangan` varchar(250)
,`namasiswa` varchar(50)
,`kelas` varchar(10)
);

-- --------------------------------------------------------

--
-- Stand-in structure for view `vtahfidzrekap`
-- (See below for the actual view)
--
CREATE TABLE `vtahfidzrekap` (
`totaltahfidz` double
,`nis` varchar(50)
,`namasiswa` varchar(50)
,`kelas` varchar(10)
);

-- --------------------------------------------------------

--
-- Stand-in structure for view `vuangsakukeluar`
-- (See below for the actual view)
--
CREATE TABLE `vuangsakukeluar` (
`nis` double
,`namasiswa` varchar(50)
,`kelas` varchar(10)
,`namaayah` varchar(50)
,`marhalah` varchar(50)
,`totkeluar` double
);

-- --------------------------------------------------------

--
-- Stand-in structure for view `vuangsakukeluardetail`
-- (See below for the actual view)
--
CREATE TABLE `vuangsakukeluardetail` (
`nonota` double
,`nis` varchar(12)
,`uangkeluar` double
,`tanggal` date
,`pengguna` varchar(20)
,`catatan` varchar(120)
,`namasiswa` varchar(50)
,`marhalah` varchar(50)
,`kelas` varchar(10)
);

-- --------------------------------------------------------

--
-- Stand-in structure for view `vuangsakumasuk`
-- (See below for the actual view)
--
CREATE TABLE `vuangsakumasuk` (
`nis` double
,`namasiswa` varchar(50)
,`kelas` varchar(10)
,`namaayah` varchar(50)
,`marhalah` varchar(50)
,`totmasuk` double
);

-- --------------------------------------------------------

--
-- Stand-in structure for view `vuangsakusisa`
-- (See below for the actual view)
--
CREATE TABLE `vuangsakusisa` (
`nis` double
,`namasiswa` varchar(50)
,`kelas` varchar(10)
,`namaayah` varchar(50)
,`marhalah` varchar(50)
,`totmasuk` double
,`totkeluar` double
,`uangsisa` double
);

-- --------------------------------------------------------

--
-- Structure for view `vabsensisiswa`
--
DROP TABLE IF EXISTS `vabsensisiswa`;

CREATE ALGORITHM=UNDEFINED DEFINER=`sipy1897`@`localhost` SQL SECURITY DEFINER VIEW `vabsensisiswa`  AS  select `absen`.`nourut` AS `nourut`,`absen`.`nis` AS `nis`,`absen`.`tanggal` AS `tanggal`,`absen`.`tanggalakhir` AS `tanggalakhir`,`absen`.`sakit` AS `sakit`,`absen`.`ijin` AS `ijin`,`absen`.`alpa` AS `alpa`,`absen`.`catatan` AS `catatan`,`absen`.`pengguna` AS `pengguna`,`siswa`.`namasiswa` AS `namasiswa`,`siswa`.`marhalah` AS `marhalah`,`siswa`.`kelas` AS `kelas` from (`absen` join `siswa` on((`absen`.`nis` = `siswa`.`nis`))) ;

-- --------------------------------------------------------

--
-- Structure for view `vdaftarnilaikosong`
--
DROP TABLE IF EXISTS `vdaftarnilaikosong`;

CREATE ALGORITHM=UNDEFINED DEFINER=`sipy1897`@`localhost` SQL SECURITY DEFINER VIEW `vdaftarnilaikosong`  AS  select `setingmapel`.`noid` AS `noid`,`setingmapel`.`kodemapel` AS `kodemapel`,`setingmapel`.`nik` AS `nik`,`setingmapel`.`kelas` AS `kelas`,`siswa`.`namasiswa` AS `namasiswa`,`siswa`.`nis` AS `nis`,`pegawai`.`nama` AS `nama` from ((`setingmapel` join `siswa` on((`setingmapel`.`kelas` = `siswa`.`kelas`))) join `pegawai` on((`setingmapel`.`nik` = `pegawai`.`nik`))) ;

-- --------------------------------------------------------

--
-- Structure for view `vjurnal`
--
DROP TABLE IF EXISTS `vjurnal`;

CREATE ALGORITHM=UNDEFINED DEFINER=`sipy1897`@`localhost` SQL SECURITY DEFINER VIEW `vjurnal`  AS  select `jurnal`.`nourut` AS `nourut`,`jurnal`.`tanggal` AS `tanggal`,`jurnal`.`nonota` AS `nonota`,`jurnal`.`koderekening` AS `koderekening`,`jurnal`.`debet` AS `debet`,`jurnal`.`kredit` AS `kredit`,`jurnal`.`keterangan` AS `keterangan`,`jurnal`.`pengguna` AS `pengguna`,`rekening`.`namarekening` AS `namarekening`,`rekening`.`normal` AS `normal` from (`jurnal` join `rekening` on((`jurnal`.`koderekening` = `rekening`.`koderekening`))) ;

-- --------------------------------------------------------

--
-- Structure for view `vkesehatan`
--
DROP TABLE IF EXISTS `vkesehatan`;

CREATE ALGORITHM=UNDEFINED DEFINER=`sipy1897`@`localhost` SQL SECURITY DEFINER VIEW `vkesehatan`  AS  select `kesehatan`.`nourut` AS `nourut`,`kesehatan`.`tanggal` AS `tanggal`,`kesehatan`.`nis` AS `nis`,`kesehatan`.`keluhan` AS `keluhan`,`kesehatan`.`obat` AS `obat`,`kesehatan`.`catatan` AS `catatan`,`kesehatan`.`keparahan` AS `keparahan`,`kesehatan`.`pengguna` AS `pengguna`,`siswa`.`namasiswa` AS `namasiswa`,`siswa`.`marhalah` AS `marhalah`,`siswa`.`kelas` AS `kelas` from (`kesehatan` join `siswa` on((`kesehatan`.`nis` = `siswa`.`nis`))) ;

-- --------------------------------------------------------

--
-- Structure for view `vmonitoringspp`
--
DROP TABLE IF EXISTS `vmonitoringspp`;

CREATE ALGORITHM=UNDEFINED DEFINER=`sipy1897`@`localhost` SQL SECURITY DEFINER VIEW `vmonitoringspp`  AS  select `monitoringspp`.`nis` AS `nis`,`monitoringspp`.`setpoin` AS `setpoin`,`monitoringspp`.`kesanggupan` AS `kesanggupan`,`monitoringspp`.`juli` AS `juli`,`monitoringspp`.`agustus` AS `agustus`,`monitoringspp`.`september` AS `september`,`monitoringspp`.`oktober` AS `oktober`,`monitoringspp`.`november` AS `november`,`monitoringspp`.`desember` AS `desember`,`monitoringspp`.`januari` AS `januari`,`monitoringspp`.`februari` AS `februari`,`monitoringspp`.`maret` AS `maret`,`monitoringspp`.`april` AS `april`,`monitoringspp`.`mei` AS `mei`,`monitoringspp`.`juni` AS `juni`,`monitoringspp`.`piutang` AS `piutang`,`monitoringspp`.`juli2` AS `juli2`,`monitoringspp`.`agustus2` AS `agustus2`,`siswa`.`namasiswa` AS `namasiswa`,`siswa`.`marhalah` AS `marhalah`,`siswa`.`kelas` AS `kelas`,`siswa`.`namaayah` AS `namaayah`,`siswa`.`namaibu` AS `namaibu` from (`monitoringspp` join `siswa` on((`monitoringspp`.`nis` = `siswa`.`nis`))) ;

-- --------------------------------------------------------

--
-- Structure for view `vneracasaldo`
--
DROP TABLE IF EXISTS `vneracasaldo`;

CREATE ALGORITHM=UNDEFINED DEFINER=`sipy1897`@`localhost` SQL SECURITY DEFINER VIEW `vneracasaldo`  AS  select sum(`jurnal`.`debet`) AS `totdebet`,sum(`jurnal`.`kredit`) AS `totkredit`,`jurnal`.`koderekening` AS `koderekening`,`rekening`.`namarekening` AS `namarekening` from (`jurnal` join `rekening` on((`jurnal`.`koderekening` = `rekening`.`koderekening`))) group by `jurnal`.`koderekening`,`rekening`.`namarekening` ;

-- --------------------------------------------------------

--
-- Structure for view `vnilai`
--
DROP TABLE IF EXISTS `vnilai`;

CREATE ALGORITHM=UNDEFINED DEFINER=`sipy1897`@`localhost` SQL SECURITY DEFINER VIEW `vnilai`  AS  select `nilai2`.`id` AS `id`,`nilai2`.`nis` AS `nis`,`nilai2`.`mapel` AS `mapel`,`nilai2`.`nilai` AS `nilai`,`nilai2`.`settingmapel_id` AS `settingmapel_id`,`siswa`.`namasiswa` AS `namasiswa`,`siswa`.`kelas` AS `kelas`,`vsetingmapel`.`namamapel` AS `namamapel`,`vsetingmapel`.`nama` AS `nama`,`vsetingmapel`.`kodemapel` AS `kodemapel`,`vsetingmapel`.`nik` AS `nik` from ((`nilai2` join `siswa` on((`nilai2`.`nis` = `siswa`.`nis`))) join `vsetingmapel` on((`nilai2`.`settingmapel_id` = `vsetingmapel`.`noid`))) ;

-- --------------------------------------------------------

--
-- Structure for view `vnilairata`
--
DROP TABLE IF EXISTS `vnilairata`;

CREATE ALGORITHM=UNDEFINED DEFINER=`sipy1897`@`localhost` SQL SECURITY DEFINER VIEW `vnilairata`  AS  select `vnilai`.`nis` AS `nis`,`vnilai`.`namasiswa` AS `namasiswa`,`vnilai`.`kelas` AS `kelas`,sum(`vnilai`.`nilai`) AS `totnilai`,count(`vnilai`.`nilai`) AS `totmapel`,(sum(`vnilai`.`nilai`) / count(`vnilai`.`nilai`)) AS `ratanilai` from `vnilai` group by `vnilai`.`nis`,`vnilai`.`namasiswa`,`vnilai`.`kelas` ;

-- --------------------------------------------------------

--
-- Structure for view `vpelanggaran`
--
DROP TABLE IF EXISTS `vpelanggaran`;

CREATE ALGORITHM=UNDEFINED DEFINER=`sipy1897`@`localhost` SQL SECURITY DEFINER VIEW `vpelanggaran`  AS  select `pelanggaran`.`nourut` AS `nourut`,`pelanggaran`.`tanggal` AS `tanggal`,`pelanggaran`.`nis` AS `nis`,`pelanggaran`.`namapelanggaran` AS `namapelanggaran`,`pelanggaran`.`tindakan` AS `tindakan`,`pelanggaran`.`poin` AS `poin`,`pelanggaran`.`pengguna` AS `pengguna`,`siswa`.`namasiswa` AS `namasiswa`,`siswa`.`marhalah` AS `marhalah`,`siswa`.`kelas` AS `kelas` from (`pelanggaran` join `siswa` on((`pelanggaran`.`nis` = `siswa`.`nis`))) ;

-- --------------------------------------------------------

--
-- Structure for view `vpelanggaranrekap`
--
DROP TABLE IF EXISTS `vpelanggaranrekap`;

CREATE ALGORITHM=UNDEFINED DEFINER=`sipy1897`@`localhost` SQL SECURITY DEFINER VIEW `vpelanggaranrekap`  AS  select sum(`vpelanggaran`.`poin`) AS `totalpoin`,`vpelanggaran`.`namasiswa` AS `namasiswa`,`vpelanggaran`.`nis` AS `nis`,`vpelanggaran`.`kelas` AS `kelas` from `vpelanggaran` group by `vpelanggaran`.`namasiswa`,`vpelanggaran`.`nis`,`vpelanggaran`.`kelas` ;

-- --------------------------------------------------------

--
-- Structure for view `vpenerimaan`
--
DROP TABLE IF EXISTS `vpenerimaan`;

CREATE ALGORITHM=UNDEFINED DEFINER=`sipy1897`@`localhost` SQL SECURITY DEFINER VIEW `vpenerimaan`  AS  select `bayarrutin`.`nis` AS `nis`,`bayarrutin`.`tanggal` AS `tanggal`,`bayarrutin`.`nonota` AS `nonota`,`bayarrutin`.`transfer` AS `transfer`,`bayarrutin`.`pengguna` AS `pengguna`,`bayarrutin`.`tanggaldokumen` AS `tanggaldokumen`,((((((((((((((((`bayarrutin`.`januari` + `bayarrutin`.`februari`) + `bayarrutin`.`maret`) + `bayarrutin`.`april`) + `bayarrutin`.`mei`) + `bayarrutin`.`juni`) + `bayarrutin`.`juli`) + `bayarrutin`.`agustus`) + `bayarrutin`.`september`) + `bayarrutin`.`oktober`) + `bayarrutin`.`november`) + `bayarrutin`.`desember`) + `bayarrutin`.`uangpangkal`) + `bayarrutin`.`daftarulang`) + `bayarrutin`.`infaq`) + `bayarrutin`.`uangsakumasuk`) + `bayarrutin`.`bimbel`) AS `total`,`siswa`.`namasiswa` AS `namasiswa`,`siswa`.`kelas` AS `kelas`,`siswa`.`namaayah` AS `namaayah`,`siswa`.`telephon` AS `telephon` from (`bayarrutin` join `siswa` on((`bayarrutin`.`nis` = `siswa`.`nis`))) ;

-- --------------------------------------------------------

--
-- Structure for view `vperizinan`
--
DROP TABLE IF EXISTS `vperizinan`;

CREATE ALGORITHM=UNDEFINED DEFINER=`sipy1897`@`localhost` SQL SECURITY DEFINER VIEW `vperizinan`  AS  select `izin`.`nourut` AS `nourut`,`izin`.`nis` AS `nis`,`izin`.`tanggalizin` AS `tanggalizin`,`izin`.`tanggalkembali` AS `tanggalkembali`,`izin`.`penjemput` AS `penjemput`,`izin`.`catatan` AS `catatan`,`siswa`.`namasiswa` AS `namasiswa`,`siswa`.`marhalah` AS `marhalah`,`siswa`.`kelas` AS `kelas` from (`izin` join `siswa` on((`izin`.`nis` = `siswa`.`nis`))) ;

-- --------------------------------------------------------

--
-- Structure for view `vprestasi`
--
DROP TABLE IF EXISTS `vprestasi`;

CREATE ALGORITHM=UNDEFINED DEFINER=`sipy1897`@`localhost` SQL SECURITY DEFINER VIEW `vprestasi`  AS  select `prestasi`.`nourut` AS `nourut`,`prestasi`.`tanggal` AS `tanggal`,`prestasi`.`nis` AS `nis`,`prestasi`.`prestasi` AS `prestasi`,`prestasi`.`catatan` AS `catatan`,`prestasi`.`pengguna` AS `pengguna`,`siswa`.`namasiswa` AS `namasiswa`,`siswa`.`marhalah` AS `marhalah`,`siswa`.`kelas` AS `kelas` from (`prestasi` join `siswa` on((`prestasi`.`nis` = `siswa`.`nis`))) ;

-- --------------------------------------------------------

--
-- Structure for view `vselainspp`
--
DROP TABLE IF EXISTS `vselainspp`;

CREATE ALGORITHM=UNDEFINED DEFINER=`sipy1897`@`localhost` SQL SECURITY DEFINER VIEW `vselainspp`  AS  select `bayarrutin`.`nis` AS `nis`,`bayarrutin`.`tanggal` AS `tanggal`,`bayarrutin`.`nonota` AS `nonota`,`bayarrutin`.`transfer` AS `transfer`,`bayarrutin`.`pengguna` AS `pengguna`,`bayarrutin`.`daftarulang` AS `daftarulang`,`bayarrutin`.`uangpangkal` AS `uangpangkal`,`bayarrutin`.`infaq` AS `infaq`,`bayarrutin`.`uangsakumasuk` AS `uangsakumasuk`,`bayarrutin`.`bimbel` AS `bimbel`,`bayarrutin`.`keteranganinfaq` AS `keteranganinfaq`,`bayarrutin`.`tanggaldokumen` AS `tanggaldokumen`,`siswa`.`namasiswa` AS `namasiswa`,`siswa`.`kelas` AS `kelas`,`siswa`.`namaayah` AS `namaayah`,`siswa`.`telephon` AS `telephon` from (`bayarrutin` join `siswa` on((`bayarrutin`.`nis` = `siswa`.`nis`))) ;

-- --------------------------------------------------------

--
-- Structure for view `vsetingmapel`
--
DROP TABLE IF EXISTS `vsetingmapel`;

CREATE ALGORITHM=UNDEFINED DEFINER=`sipy1897`@`localhost` SQL SECURITY DEFINER VIEW `vsetingmapel`  AS  select `setingmapel`.`noid` AS `noid`,`setingmapel`.`kodemapel` AS `kodemapel`,`setingmapel`.`nik` AS `nik`,`setingmapel`.`kelas` AS `kelas`,`matapelajaran`.`namamapel` AS `namamapel`,`pegawai`.`nama` AS `nama`,`kelas`.`walikelas` AS `walikelas` from (((`setingmapel` join `matapelajaran` on((`setingmapel`.`kodemapel` = `matapelajaran`.`kodemapel`))) join `pegawai` on((`setingmapel`.`nik` = `pegawai`.`nik`))) join `kelas` on((`setingmapel`.`kelas` = convert(`kelas`.`namakelas` using utf8)))) ;

-- --------------------------------------------------------

--
-- Structure for view `vsiswakeluar`
--
DROP TABLE IF EXISTS `vsiswakeluar`;

CREATE ALGORITHM=UNDEFINED DEFINER=`sipy1897`@`localhost` SQL SECURITY DEFINER VIEW `vsiswakeluar`  AS  select `siswakeluar`.`nis` AS `nis`,`siswakeluar`.`tanggal` AS `tanggal`,`siswakeluar`.`keterangan` AS `keterangan`,`siswa`.`namasiswa` AS `namasiswa`,`siswa`.`marhalah` AS `marhalah`,`siswa`.`kelas` AS `kelas`,`siswa`.`namaayah` AS `namaayah`,`siswa`.`namaibu` AS `namaibu` from (`siswakeluar` join `siswa` on((`siswakeluar`.`nis` = `siswa`.`nis`))) ;

-- --------------------------------------------------------

--
-- Structure for view `vspp`
--
DROP TABLE IF EXISTS `vspp`;

CREATE ALGORITHM=UNDEFINED DEFINER=`sipy1897`@`localhost` SQL SECURITY DEFINER VIEW `vspp`  AS  select `bayarrutin`.`nis` AS `nis`,`bayarrutin`.`tanggal` AS `tanggal`,`bayarrutin`.`nonota` AS `nonota`,`bayarrutin`.`transfer` AS `transfer`,`bayarrutin`.`pengguna` AS `pengguna`,`bayarrutin`.`januari` AS `januari`,`bayarrutin`.`februari` AS `februari`,`bayarrutin`.`maret` AS `maret`,`bayarrutin`.`april` AS `april`,`bayarrutin`.`mei` AS `mei`,`bayarrutin`.`juni` AS `juni`,`bayarrutin`.`juli` AS `juli`,`bayarrutin`.`agustus` AS `agustus`,`bayarrutin`.`september` AS `september`,`bayarrutin`.`oktober` AS `oktober`,`bayarrutin`.`november` AS `november`,`bayarrutin`.`desember` AS `desember`,`bayarrutin`.`tanggaldokumen` AS `tanggaldokumen`,`siswa`.`namasiswa` AS `namasiswa`,`siswa`.`kelas` AS `kelas`,`siswa`.`namaayah` AS `namaayah`,`siswa`.`telephon` AS `telephon` from (`bayarrutin` join `siswa` on((`bayarrutin`.`nis` = `siswa`.`nis`))) ;

-- --------------------------------------------------------

--
-- Structure for view `vtagihan`
--
DROP TABLE IF EXISTS `vtagihan`;

CREATE ALGORITHM=UNDEFINED DEFINER=`sipy1897`@`localhost` SQL SECURITY DEFINER VIEW `vtagihan`  AS  select `bayarrutin`.`nis` AS `nis`,sum(`bayarrutin`.`uangpangkal`) AS `totaluangpangkal`,`siswa`.`uangpangkal` AS `uangpangkal`,(`siswa`.`uangpangkal` - sum(`bayarrutin`.`uangpangkal`)) AS `kuranguangpangkal`,sum(`bayarrutin`.`daftarulang`) AS `totaldaftarulang`,`siswa`.`daftarulang` AS `daftarulang`,(`siswa`.`daftarulang` - sum(`bayarrutin`.`daftarulang`)) AS `totaldaftarualng`,sum(`bayarrutin`.`bimbel`) AS `totalbimbel`,`monitoringspp`.`januari` AS `januari`,`monitoringspp`.`februari` AS `februari`,`monitoringspp`.`maret` AS `maret`,`monitoringspp`.`april` AS `april`,`monitoringspp`.`mei` AS `mei`,`monitoringspp`.`juni` AS `juni`,`monitoringspp`.`juli` AS `juli`,`monitoringspp`.`agustus` AS `agustus`,`monitoringspp`.`september` AS `september`,`monitoringspp`.`oktober` AS `oktober`,`monitoringspp`.`november` AS `november`,`monitoringspp`.`desember` AS `desember`,`siswa`.`namasiswa` AS `namasiswa`,`siswa`.`kelas` AS `kelas`,`siswa`.`telephon` AS `telephon`,`siswa`.`namaayah` AS `namaayah` from ((`bayarrutin` join `siswa` on((`bayarrutin`.`nis` = `siswa`.`nis`))) join `monitoringspp` on((`siswa`.`nis` = `monitoringspp`.`nis`))) group by `bayarrutin`.`nis`,`siswa`.`namasiswa`,`siswa`.`kelas`,`siswa`.`telephon`,`siswa`.`namaayah`,`monitoringspp`.`januari`,`monitoringspp`.`februari`,`monitoringspp`.`maret`,`monitoringspp`.`april`,`monitoringspp`.`mei`,`monitoringspp`.`juni`,`monitoringspp`.`juli`,`monitoringspp`.`agustus`,`monitoringspp`.`september`,`monitoringspp`.`oktober`,`monitoringspp`.`november`,`monitoringspp`.`desember` ;

-- --------------------------------------------------------

--
-- Structure for view `vtahfidz`
--
DROP TABLE IF EXISTS `vtahfidz`;

CREATE ALGORITHM=UNDEFINED DEFINER=`sipy1897`@`localhost` SQL SECURITY DEFINER VIEW `vtahfidz`  AS  select `tahfidz`.`nourut` AS `nourut`,`tahfidz`.`tanggal` AS `tanggal`,`tahfidz`.`nis` AS `nis`,`tahfidz`.`tambahan` AS `tambahan`,`tahfidz`.`murojaah` AS `murojaah`,`tahfidz`.`totalhafalan` AS `totalhafalan`,`tahfidz`.`murojaahbaru` AS `murojaahbaru`,`tahfidz`.`tambahanketerangan` AS `tambahanketerangan`,`siswa`.`namasiswa` AS `namasiswa`,`siswa`.`kelas` AS `kelas` from (`tahfidz` join `siswa` on((`tahfidz`.`nis` = `siswa`.`nis`))) ;

-- --------------------------------------------------------

--
-- Structure for view `vtahfidzrekap`
--
DROP TABLE IF EXISTS `vtahfidzrekap`;

CREATE ALGORITHM=UNDEFINED DEFINER=`sipy1897`@`localhost` SQL SECURITY DEFINER VIEW `vtahfidzrekap`  AS  select sum(`vtahfidz`.`tambahan`) AS `totaltahfidz`,`vtahfidz`.`nis` AS `nis`,`vtahfidz`.`namasiswa` AS `namasiswa`,`vtahfidz`.`kelas` AS `kelas` from `vtahfidz` group by `vtahfidz`.`nis`,`vtahfidz`.`namasiswa`,`vtahfidz`.`kelas` ;

-- --------------------------------------------------------

--
-- Structure for view `vuangsakukeluar`
--
DROP TABLE IF EXISTS `vuangsakukeluar`;

CREATE ALGORITHM=UNDEFINED DEFINER=`sipy1897`@`localhost` SQL SECURITY DEFINER VIEW `vuangsakukeluar`  AS  select `siswa`.`nis` AS `nis`,`siswa`.`namasiswa` AS `namasiswa`,`siswa`.`kelas` AS `kelas`,`siswa`.`namaayah` AS `namaayah`,`siswa`.`marhalah` AS `marhalah`,sum(`uangsakukeluar`.`uangkeluar`) AS `totkeluar` from (`uangsakukeluar` join `siswa` on((`uangsakukeluar`.`nis` = `siswa`.`nis`))) group by `siswa`.`nis`,`siswa`.`namasiswa`,`siswa`.`kelas`,`siswa`.`namaayah`,`siswa`.`marhalah` ;

-- --------------------------------------------------------

--
-- Structure for view `vuangsakukeluardetail`
--
DROP TABLE IF EXISTS `vuangsakukeluardetail`;

CREATE ALGORITHM=UNDEFINED DEFINER=`sipy1897`@`localhost` SQL SECURITY DEFINER VIEW `vuangsakukeluardetail`  AS  select `uangsakukeluar`.`nonota` AS `nonota`,`uangsakukeluar`.`nis` AS `nis`,`uangsakukeluar`.`uangkeluar` AS `uangkeluar`,`uangsakukeluar`.`tanggal` AS `tanggal`,`uangsakukeluar`.`pengguna` AS `pengguna`,`uangsakukeluar`.`catatan` AS `catatan`,`siswa`.`namasiswa` AS `namasiswa`,`siswa`.`marhalah` AS `marhalah`,`siswa`.`kelas` AS `kelas` from (`uangsakukeluar` join `siswa` on((`uangsakukeluar`.`nis` = `siswa`.`nis`))) ;

-- --------------------------------------------------------

--
-- Structure for view `vuangsakumasuk`
--
DROP TABLE IF EXISTS `vuangsakumasuk`;

CREATE ALGORITHM=UNDEFINED DEFINER=`sipy1897`@`localhost` SQL SECURITY DEFINER VIEW `vuangsakumasuk`  AS  select `siswa`.`nis` AS `nis`,`siswa`.`namasiswa` AS `namasiswa`,`siswa`.`kelas` AS `kelas`,`siswa`.`namaayah` AS `namaayah`,`siswa`.`marhalah` AS `marhalah`,sum(`bayarrutin`.`uangsakumasuk`) AS `totmasuk` from (`bayarrutin` join `siswa` on((`bayarrutin`.`nis` = `siswa`.`nis`))) group by `siswa`.`nis`,`siswa`.`namasiswa`,`siswa`.`kelas`,`siswa`.`namaayah`,`siswa`.`marhalah` ;

-- --------------------------------------------------------

--
-- Structure for view `vuangsakusisa`
--
DROP TABLE IF EXISTS `vuangsakusisa`;

CREATE ALGORITHM=UNDEFINED DEFINER=`sipy1897`@`localhost` SQL SECURITY DEFINER VIEW `vuangsakusisa`  AS  select `vuangsakumasuk`.`nis` AS `nis`,`vuangsakumasuk`.`namasiswa` AS `namasiswa`,`vuangsakumasuk`.`kelas` AS `kelas`,`vuangsakumasuk`.`namaayah` AS `namaayah`,`vuangsakumasuk`.`marhalah` AS `marhalah`,`vuangsakumasuk`.`totmasuk` AS `totmasuk`,ifnull(`vuangsakukeluar`.`totkeluar`,0) AS `totkeluar`,(ifnull(`vuangsakumasuk`.`totmasuk`,0) - ifnull(`vuangsakukeluar`.`totkeluar`,0)) AS `uangsisa` from (`vuangsakumasuk` left join `vuangsakukeluar` on((`vuangsakumasuk`.`nis` = `vuangsakukeluar`.`nis`))) ;

--
-- Indexes for dumped tables
--

--
-- Indexes for table `aaa`
--
ALTER TABLE `aaa`
  ADD PRIMARY KEY (`nourut`);

--
-- Indexes for table `aaa2`
--
ALTER TABLE `aaa2`
  ADD PRIMARY KEY (`nourut`);

--
-- Indexes for table `absen`
--
ALTER TABLE `absen`
  ADD PRIMARY KEY (`nourut`);

--
-- Indexes for table `acl_groups`
--
ALTER TABLE `acl_groups`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `acl_menus`
--
ALTER TABLE `acl_menus`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `acl_routes`
--
ALTER TABLE `acl_routes`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `acl_users`
--
ALTER TABLE `acl_users`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `ambilformulir`
--
ALTER TABLE `ambilformulir`
  ADD PRIMARY KEY (`nopendaftaran`);

--
-- Indexes for table `bayarrutin`
--
ALTER TABLE `bayarrutin`
  ADD PRIMARY KEY (`nonota`);

--
-- Indexes for table `berita`
--
ALTER TABLE `berita`
  ADD PRIMARY KEY (`noberita`);

--
-- Indexes for table `groups`
--
ALTER TABLE `groups`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `isiformulir`
--
ALTER TABLE `isiformulir`
  ADD PRIMARY KEY (`nopendaftaran`);

--
-- Indexes for table `izin`
--
ALTER TABLE `izin`
  ADD PRIMARY KEY (`nourut`);

--
-- Indexes for table `jurnal`
--
ALTER TABLE `jurnal`
  ADD PRIMARY KEY (`nourut`);

--
-- Indexes for table `kelas`
--
ALTER TABLE `kelas`
  ADD PRIMARY KEY (`nourut`);

--
-- Indexes for table `kesehatan`
--
ALTER TABLE `kesehatan`
  ADD PRIMARY KEY (`nourut`);

--
-- Indexes for table `marhalah`
--
ALTER TABLE `marhalah`
  ADD PRIMARY KEY (`namamarhalah`);

--
-- Indexes for table `matapelajaran`
--
ALTER TABLE `matapelajaran`
  ADD PRIMARY KEY (`kodemapel`);

--
-- Indexes for table `monitoringspp`
--
ALTER TABLE `monitoringspp`
  ADD PRIMARY KEY (`nis`);

--
-- Indexes for table `nilai2`
--
ALTER TABLE `nilai2`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `pegawai`
--
ALTER TABLE `pegawai`
  ADD PRIMARY KEY (`nik`);

--
-- Indexes for table `pelanggaran`
--
ALTER TABLE `pelanggaran`
  ADD PRIMARY KEY (`nourut`);

--
-- Indexes for table `prestasi`
--
ALTER TABLE `prestasi`
  ADD PRIMARY KEY (`nourut`);

--
-- Indexes for table `rekening`
--
ALTER TABLE `rekening`
  ADD PRIMARY KEY (`koderekening`);

--
-- Indexes for table `sekolah`
--
ALTER TABLE `sekolah`
  ADD PRIMARY KEY (`namasekolah`);

--
-- Indexes for table `setingmapel`
--
ALTER TABLE `setingmapel`
  ADD PRIMARY KEY (`noid`);

--
-- Indexes for table `siswa`
--
ALTER TABLE `siswa`
  ADD PRIMARY KEY (`nis`);

--
-- Indexes for table `siswaalumni`
--
ALTER TABLE `siswaalumni`
  ADD PRIMARY KEY (`nis`);

--
-- Indexes for table `siswakeluar`
--
ALTER TABLE `siswakeluar`
  ADD PRIMARY KEY (`nis`);

--
-- Indexes for table `tahfidz`
--
ALTER TABLE `tahfidz`
  ADD PRIMARY KEY (`nourut`);

--
-- Indexes for table `tahunajaran`
--
ALTER TABLE `tahunajaran`
  ADD PRIMARY KEY (`namatahunajaran`);

--
-- Indexes for table `test`
--
ALTER TABLE `test`
  ADD PRIMARY KEY (`userid`);

--
-- Indexes for table `uangsakukeluar`
--
ALTER TABLE `uangsakukeluar`
  ADD PRIMARY KEY (`nonota`);

--
-- Indexes for table `user`
--
ALTER TABLE `user`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `user2`
--
ALTER TABLE `user2`
  ADD PRIMARY KEY (`userid`);

--
-- Indexes for table `userhalaman`
--
ALTER TABLE `userhalaman`
  ADD PRIMARY KEY (`noid`);

--
-- Indexes for table `userorangtua`
--
ALTER TABLE `userorangtua`
  ADD PRIMARY KEY (`nourut`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `usersiswa`
--
ALTER TABLE `usersiswa`
  ADD PRIMARY KEY (`username`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `aaa`
--
ALTER TABLE `aaa`
  MODIFY `nourut` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `aaa2`
--
ALTER TABLE `aaa2`
  MODIFY `nourut` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `absen`
--
ALTER TABLE `absen`
  MODIFY `nourut` double NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `acl_groups`
--
ALTER TABLE `acl_groups`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- AUTO_INCREMENT for table `acl_menus`
--
ALTER TABLE `acl_menus`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=109;

--
-- AUTO_INCREMENT for table `acl_routes`
--
ALTER TABLE `acl_routes`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=35;

--
-- AUTO_INCREMENT for table `acl_users`
--
ALTER TABLE `acl_users`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=20;

--
-- AUTO_INCREMENT for table `ambilformulir`
--
ALTER TABLE `ambilformulir`
  MODIFY `nopendaftaran` double NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `berita`
--
ALTER TABLE `berita`
  MODIFY `noberita` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;

--
-- AUTO_INCREMENT for table `groups`
--
ALTER TABLE `groups`
  MODIFY `id` mediumint(8) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `izin`
--
ALTER TABLE `izin`
  MODIFY `nourut` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=128;

--
-- AUTO_INCREMENT for table `jurnal`
--
ALTER TABLE `jurnal`
  MODIFY `nourut` double NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=46;

--
-- AUTO_INCREMENT for table `kelas`
--
ALTER TABLE `kelas`
  MODIFY `nourut` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=72;

--
-- AUTO_INCREMENT for table `kesehatan`
--
ALTER TABLE `kesehatan`
  MODIFY `nourut` double NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=90;

--
-- AUTO_INCREMENT for table `nilai2`
--
ALTER TABLE `nilai2`
  MODIFY `id` int(32) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=137;

--
-- AUTO_INCREMENT for table `pegawai`
--
ALTER TABLE `pegawai`
  MODIFY `nik` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10016;

--
-- AUTO_INCREMENT for table `pelanggaran`
--
ALTER TABLE `pelanggaran`
  MODIFY `nourut` double NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=33;

--
-- AUTO_INCREMENT for table `prestasi`
--
ALTER TABLE `prestasi`
  MODIFY `nourut` double NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=41;

--
-- AUTO_INCREMENT for table `setingmapel`
--
ALTER TABLE `setingmapel`
  MODIFY `noid` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=43;

--
-- AUTO_INCREMENT for table `siswa`
--
ALTER TABLE `siswa`
  MODIFY `nis` double NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11700110;

--
-- AUTO_INCREMENT for table `tahfidz`
--
ALTER TABLE `tahfidz`
  MODIFY `nourut` double NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=39;

--
-- AUTO_INCREMENT for table `uangsakukeluar`
--
ALTER TABLE `uangsakukeluar`
  MODIFY `nonota` double NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `user`
--
ALTER TABLE `user`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `userhalaman`
--
ALTER TABLE `userhalaman`
  MODIFY `noid` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=75;

--
-- AUTO_INCREMENT for table `userorangtua`
--
ALTER TABLE `userorangtua`
  MODIFY `nourut` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` int(11) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
